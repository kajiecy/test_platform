package org.jsoncloud.framework.util;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import java.io.IOException;
import java.util.Date;

import static org.junit.Assert.*;

/**
 * Created by Administrator on 2017/3/26.
 */
public class ImgCodeUtilTest {
    @Before
    public void setUp() throws Exception {

    }

//    @Ignore
    @Test
    public void createCode() throws Exception {
        ImgCodeUtil vCode = new ImgCodeUtil(150,50,4,200);
        try {
            String path="D:/"+new Date().getTime()+".png";
            System.out.println(vCode.getCode()+" >"+path);
            vCode.write(path);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}