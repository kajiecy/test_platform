package org.jsoncloud.framework.util;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Administrator on 2017/4/11.
 */
public class PropertiesUtilTest {
    @Test
    public void get() throws Exception {
//        PropertiesUtil.get("2");
    }

}