package org.jsoncloud.framework.util;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Administrator on 2017/3/24.
 */
public class TokenUtilTest {
    @Test
    public void generateToken() throws Exception {
        String xx = TokenUtil.getInstance().generateToken("sd", true);
        System.out.println("------------tokneUtil：" + xx);
    }

}