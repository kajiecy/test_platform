package org.jsoncloud.framework.util;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Administrator on 2017/3/24.
 */
public class RandUtilTest {
    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void randomInt() throws Exception {
        System.out.println("-------randomInt:"+RandUtil.randomInt(10));
    }

    @Test
    public void randomString() throws Exception {
        System.out.println("-------randomString:"+RandUtil.randomString(10));

    }

    @Test
    public void randomString1() throws Exception {

        System.out.println("-------randomString1:"+RandUtil.randomString(10,false));

    }

}