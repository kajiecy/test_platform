package org.jsoncloud.framework.util;

import org.apache.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesUtil {

    private static Properties pro;
    private static Logger logger = Logger.getLogger(PropertiesUtil.class);

    protected PropertiesUtil() {
    }

    static {
        pro = new Properties();
        InputStream i = (PropertiesUtil.class
                .getResourceAsStream("/common.properties"));
        try {
            pro.load(i);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static public String get(String name) {
        return pro.getProperty(name);
    }

    static public String getMust(String name) {
        return getMust(name,null);
    }

    static public String getMust(String name, String tip) {
        String val = pro.getProperty(name);
        if (val == null || val.equals("")) {
            String errorInfo = "【配置[common.properties]获取信息失败：" + StringUtil.toString(tip, "[" + name + "]缺失") + "】";
            logger.error(errorInfo);
            throw new RuntimeException(errorInfo);
        }
        return val;
    }

    static public int getInt(String name) {
        return Integer.parseInt(pro.getProperty(name));
    }

}
