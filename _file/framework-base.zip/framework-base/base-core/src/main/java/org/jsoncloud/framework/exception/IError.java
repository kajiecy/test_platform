package org.jsoncloud.framework.exception;

/**
 * 错误信息枚举接口
 */
public interface IError {

    int getCode();
    String getDescribeCn();
    String getDescribeEn();

}
