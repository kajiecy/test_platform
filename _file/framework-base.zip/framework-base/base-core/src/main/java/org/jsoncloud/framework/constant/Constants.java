package org.jsoncloud.framework.constant;

/**
 * 全局常量
 *
 * @author Bames
 */
public class Constants {
    /**
     * 验证码类型 登录
     */
    public static final int CODE_LOGIN = 0;
    /**
     * 验证码类型 注册
     */
    public static final int CODE_REGISTER = 1;
    /**
     * 验证码类型 验证手机
     */
    public static final int CODE_VALID_PHONE = 2;
    /**
     * 验证码类型 改密码
     */
    public static final int CODE_MODIFY_PWD = 3;

    /**
     * 验证码int session标记 登录
     */
    public static final String SESSION_CODE_LOGIN = "session_code_login";
    /**
     * 验证码 session标记 注册
     */
    public static final String SESSION_CODE_REGISTER = "session_code_register";
    /**
     * 验证码 session标记 手机验证
     */
    public static final String SESSION_CODE_VALID_PHONE = "session_code_valid_phone";
    /**
     * 验证码 session标记 改密码
     */
    public static final String SESSION_CODE_MODIFY_PWD = "session_code_modify_pwd";

    /***
     * 已经登录用户 session标记
     */
    public static final String SESSION_LOGIN_USER = "login_user";

    /**
     * servletContext中的系统参数
     */
    public static final String APP_CONFIG = "app_config";
}
