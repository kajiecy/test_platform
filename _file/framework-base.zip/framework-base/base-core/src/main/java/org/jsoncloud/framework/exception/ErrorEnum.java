package org.jsoncloud.framework.exception;

/**
 * Created by Administrator on 2017/3/19.
 */
public enum ErrorEnum implements IError {

    UNKNOWN(1000,"未知错误","")
    ,SYSTEM(1001,"系统错误","")
    ,INVALID_NULL(1002,"参数不可为空","")
    ,INVALID_TYPE(1003,"参数数据类型不匹配","")
    ,INVALID_LOST(1004,"记录不存在","")
    ,INVALID_VALUE(1005,"参数值无效","")
    ,USER_NOT_LOGIN(2000,"用户未登录","")
    ;
    ErrorEnum(int code, String describeCn, String describeEn) {
        this.code = code;
        this.describeCn = describeCn;
        this.describeEn = describeEn;
    }

    private int code;
    private String describeCn;
    private String describeEn;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDescribeCn() {
        return describeCn;
    }

    public void setDescribeCn(String describeCn) {
        this.describeCn = describeCn;
    }

    public String getDescribeEn() {
        return describeEn;
    }

    public void setDescribeEn(String describeEn) {
        this.describeEn = describeEn;
    }

}
