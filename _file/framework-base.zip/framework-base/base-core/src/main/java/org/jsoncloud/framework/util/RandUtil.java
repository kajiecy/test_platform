package org.jsoncloud.framework.util;

import java.util.Random;

/**
 * 随机工具
 *
 * @author Bames
 */
public class RandUtil {

    private static final String alpha = "0123456789abcdefghijklmnopqrstuvwxyz";

    /**
     * 随机数字
     *
     * @param length
     * @return
     */
    static public int randomInt(int length) {
        length = Math.abs(length);
        Random rand = new Random();
        int base = (int) Math.pow(10, length - 1);
        int limit = (int) Math.pow(10, length) - base;
        return rand.nextInt(limit) + base;
    }

    static public int randomInt(int min, int max) {
//        int max=20;
//        int min=10;
        Random random = new Random();
        int s = random.nextInt(max) % (max - min + 1) + min;
        return s;
    }

    static public String randomString(int length) {
        return randomString(length, true);
    }

    static public String randomString(int length, boolean withinBigLetter) {
        Random r = new Random();
        length = Math.abs(length);
        char[] result = new char[length];
        for (int i = 0; i < length; i++) {
            char c = alpha.charAt(r.nextInt(alpha.length()));
            if (withinBigLetter && r.nextBoolean()) {
                c = Character.toUpperCase(c);
            }
            result[i] = c;
        }
        return new String(result);
    }


}
