package org.jsoncloud.framework.exception;

/**
 * 参数异常
 * 
 * @author Bames
 * 
 */
public class CommonException extends Exception {

	private static final long serialVersionUID = 1L;
	private Integer errorCode;

	public CommonException(int errorCode) {
		this.errorCode = errorCode;
	}

	public CommonException(int errorCode, String message) {
		super(message);
		this.errorCode = errorCode;
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(Integer errorCode) {
		this.errorCode = errorCode;
	}

}
