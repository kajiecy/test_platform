package org.jsoncloud.framework.util;

import java.util.Date;
import java.util.UUID;

/**
 * 订单号帮助类
 */
public class OrderNumberUtil {

    /**
     * 获取,时间戳+UUID 22位
     * @return
     */
    public static String uuid() {
        int hashCodeV = UUID.randomUUID().toString().hashCode();
        if (hashCodeV < 0) {//有可能是负数
            hashCodeV = -hashCodeV;
        }
        // 0 代表前面补充0
        // 4 代表长度为4
        // d 代表参数为正数型
        String uuid = String.format("%010d", hashCodeV);
        String datetime = DateUtil.date2String(new Date(), "yyMMddHHmmss");
        return datetime + uuid;
    }

}
