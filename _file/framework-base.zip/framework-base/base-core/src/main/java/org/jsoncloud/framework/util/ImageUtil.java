package org.jsoncloud.framework.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * 图片编码解码工具
 * 
 * @author Bames
 * 
 */
public class ImageUtil {

	public static void main(String[] args) {
		File file = new File("E:\\icon.jpg");
		String encFile = encodeFromFile(file);
		System.out.println(encFile);
		decodeToFile(encFile, new File("E:\\test002.jpg"));
	}

	public static String encodeFromFile(File iamge) {
		BASE64Encoder encoder = new BASE64Encoder();
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(iamge);
			byte[] b = new byte[fis.available()];
			fis.read(b);
			return encoder.encode(b);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	static public byte[] decode(String imageStr) {
		if (imageStr == null)
			return null;
		BASE64Decoder decoder = new BASE64Decoder();
		try {
			byte[] buffer = decoder.decodeBuffer(imageStr);
			for (int i = 0; i < buffer.length; i++) {
				if (buffer[i] < 0)
					buffer[i] += 256;
			}
			return buffer;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	static public void decodeToFile(byte[] imageData, File dest) {
		if (imageData == null || dest == null)
			return;
		FileOutputStream fos = null;
		try {
			byte[] buffer = imageData;
			for (int i = 0; i < buffer.length; i++) {
				if (buffer[i] < 0)
					buffer[i] += 256;
			}
			fos = new FileOutputStream(dest, false);
			fos.write(buffer);
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fos != null)
				try {
					fos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}

	static public void decodeToFile(String imageStr, File dest) {
		if (imageStr == null || dest == null)
			return;
		BASE64Decoder decoder = new BASE64Decoder();
		FileOutputStream fos = null;
		try {
			byte[] buffer = decoder.decodeBuffer(imageStr);
			for (int i = 0; i < buffer.length; i++) {
				if (buffer[i] < 0)
					buffer[i] += 256;
			}
			fos = new FileOutputStream(dest, false);
			fos.write(buffer);
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fos != null)
				try {
					fos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}

}
