package org.jsoncloud.framework.util;

import java.text.NumberFormat;

public class NumberUtil {


    public static String format(double val) {
        NumberFormat nf = NumberFormat.getNumberInstance();
        return nf.format(val);
    }

    public static Long parseLong(Object val, Long defaultVal) {
        if (val == null)
            return defaultVal;
        try {
            return Long.parseLong(val.toString());
        } catch (NumberFormatException e) {
            return defaultVal;
        }
    }

    public static Integer parseInt(Object val, Integer defaultVal) {
        if (val == null)
            return defaultVal;
        try {
            return Integer.parseInt(val.toString());
        } catch (NumberFormatException e) {
            return defaultVal;
        }
    }

    public static Double parseDouble(String val, Double defaultVal) {
        if (val == null)
            return defaultVal;
        try {
            return Double.parseDouble(val.toString());
        } catch (NumberFormatException e) {
            return defaultVal;
        }
    }

}
