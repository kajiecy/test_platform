package org.jsoncloud.framework.exception;

/**
 * 支付异常
 * 
 * @author Bames
 * 
 */
public class PayException extends Exception {

	private static final long serialVersionUID = 2L;
	private Integer errorCode;

	public PayException(int errorCode) {
		this.errorCode = errorCode;
	}

	public PayException(int errorCode, String message) {
		super(message);
		this.errorCode = errorCode;
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(Integer errorCode) {
		this.errorCode = errorCode;
	}

}
