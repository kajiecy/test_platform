package org.jsoncloud.framework.bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 分页
 * 
 * @author Bames
 */
public class Page {

	@Override
	public String toString() {
		return "Page [start=" + start + ", limit=" + limit + ", total=" + total + ", totalPage=" + totalPage
				+ ", pageIndex=" + pageIndex + ", condition=" + condition + ", results=" + results + "]";
	}

	private int start = 0;
	private int limit = 5;
	private int total;// 总数
	private int totalPage;// 总页数
	private int pageIndex;

	private Map<String, Object> condition = new HashMap<String, Object>();
	private List<Map<String, Object>> results = new ArrayList<>();

	public void set(String name, Object value) {
		this.condition.put(name, value);
	}

	public void addCondition(Map<String, Object> condition) {
		if (condition == null || condition.isEmpty())
			return;
		this.condition.putAll(condition);
	}

	public Map<String, Object> getCondition() {
		return condition;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public int getPageIndex() {
		return pageIndex;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public void setPageIndexSize(Integer pageIndex, Integer pageSize) {
		if (pageIndex == null || pageIndex <= 0)
			pageIndex = 1;
		this.pageIndex = pageIndex;
		if (pageSize == null || pageSize <= 0) {
			pageSize = 10;
		}
		this.limit = pageSize;
		this.start = (pageIndex - 1) * pageSize;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
		this.totalPage = (int) Math.ceil((double) total / this.limit);
	}

	public List<Map<String, Object>> getResults() {
		return results;
	}

	public void setResults(List<Map<String, Object>> results) {
		this.results = results;
	}

}
