package org.jsoncloud.framework.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class DateUtil {

    /**
     * yyyy-MM-dd HH:mm:ss
     *
     * @return
     */
    public static String getNowTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(new Date());
    }

    /**
     * yyyy-MM-dd HH:mm:ss ,translate 2011-01-12 16:41:12 to Date
     *
     * @param str
     * @return
     * @throws ParseException
     */
    public static Date string2Date(String str) throws ParseException {
        if (str == null)
            return null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date dt = sdf.parse(str);
        return dt;
    }

    public static Date string2Date(String str, String format) throws ParseException {
        if (str == null || format == null)
            return null;
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        Date dt = sdf.parse(str);
        return dt;
    }

    /**
     * yyyy-MM-dd HH:mm:ss
     *
     * @param date
     * @return
     */
    public static String date2String(Date date) {
        if (date == null)
            return null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dateStr = sdf.format(date);
        return dateStr;
    }

    public static String date2String(Date date, String format) {
        if (date == null || format == null)
            return null;
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        String dateStr = sdf.format(date);
        return dateStr;
    }

    /**
     * DATE1-DATE2
     * yyyy-MM-dd
     *
     * @param date1
     * @param date2
     * @return d1与d2的天数差
     * @throws ParseException
     */
    public static int minusDay(String date1, String date2) throws ParseException {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date dt1 = df.parse(date1);
        Date dt2 = df.parse(date2);
        // 以00:00:00为基准，所以都不能为负数
        return minusDay(dt1, dt2);
    }

    /**
     * DATE1-DATE2
     *
     * @param date1
     * @param date2
     * @return d1与d2的天数差
     * @throws ParseException
     */
    public static int minusDay(Date date1, Date date2) {
        return (int) ((date1.getTime() - date2.getTime()) / (1000 * 60 * 60 * 24));
    }

    /**
     * DATE1-DATE2
     *
     * @param date1
     * @param date2
     * @return
     * @throws ParseException
     */
    public static long minusDatetime(String date1, String date2, String format) throws ParseException {
        SimpleDateFormat df = new SimpleDateFormat(format);
        Date dt1 = df.parse(date1);
        Date dt2 = df.parse(date2);
        // 以00:00:00为基准，所以都不能为负数
        long f = TimeZone.getDefault().getRawOffset();
        return (dt1.getTime() + f) - (dt2.getTime() + f);
    }

    public static long minusDatetime(Date date1,Date date2){
        // 以00:00:00为基准，所以都不能为负数
        long f = TimeZone.getDefault().getRawOffset();
        return (date1.getTime() + f) - (date2.getTime() + f);
    }

    /**
     * @param date new Date OBj
     * @param day  2
     * @return '2014-09-09'
     */
    public static String getDateStrForAddDay(Date date, int day) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Calendar.getInstance();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, day);
        return format.format(calendar.getTime());
    }

    public static String getDateStrForAddDay(Date date, int day, String format) {
        Calendar.getInstance();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, day);
        return new SimpleDateFormat(format).format(calendar.getTime());
    }

    /***
     * yyyy-MM-dd
     *
     * @param date
     * @param week
     * @return
     */
    public static String getDateStrForAddWeek(Date date, int week) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Calendar.getInstance().clear();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.WEEK_OF_MONTH, week);
        return format.format(calendar.getTime());
    }

    public static String getDateStrForAddMonth(Date date, int month) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Calendar.getInstance().clear();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MONDAY, month);
        return format.format(calendar.getTime());
    }

    /**
     * yyyy-MM-dd HH:mm:ss
     *
     * @param date
     * @param time
     * @return
     */
    public static String getDateTimeStrForAddTimeInMillis(Date date, long time) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Calendar.getInstance().clear();
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(date.getTime() + time);
        return format.format(calendar.getTime());
    }

    /**
     * 获取本月的天数
     *
     * @param date
     * @return
     */
    public static int getDayAmountOfMonth(Date date) {
        Calendar.getInstance().clear();
        Calendar aCalendar = Calendar.getInstance(Locale.CHINA);
        aCalendar.setTime(date);
        int day = aCalendar.getActualMaximum(Calendar.DATE);
        return day;
    }

    /**
     * 获取本月的周数
     *
     * @param date
     * @return
     */
    public static int getWeekAmountOfDate(Date date) {
        Calendar.getInstance();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int i = calendar.get(Calendar.DAY_OF_WEEK);
        if (i == 1) {
            i = 7;
        } else {
            i--;
        }
        return i;
    }

    public static String getDateStrForAddMonth(Date date, int month, String format) {
        if (date == null)
            return null;
        Calendar.getInstance();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MONDAY, month);
        return new SimpleDateFormat(format).format(calendar.getTime());
    }

    /**
     * yyyy-MM-dd
     *
     * @param date
     * @param year
     * @return
     */
    public static String getDateStrForAddYear(Date date, int year) {
        if (date == null)
            return null;
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Calendar.getInstance();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.YEAR, year);
        return format.format(calendar.getTime());
    }

    public static String getDateStrForAddYear(Date date, int year, String fmt) {
        if (date == null)
            return null;
        SimpleDateFormat format = new SimpleDateFormat(fmt);
        Calendar.getInstance();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.YEAR, year);
        return format.format(calendar.getTime());
    }


    public static String getHHmmssByLong(Long y) {
        if (y <= 0) {
            return "0:0:0";
        }
        long s = y / 1000;// 秒
        long ss = s % 60;
        long m = s / 60;
        long mm = m % 60;
        long h = m / 60;
        long hh = h % 60;

        return hh + ":" + mm + ":" + ss;
    }

    /**
     * 当前时间紧凑时间型：yyyyMMddHHmmss
     *
     * @return
     */
    public static String getNow() {
        return date2String(new Date(), "yyyyMMddHHmmss");
    }
}
