package org.jsoncloud.framework.util;

import org.apache.log4j.Logger;

import java.text.ParseException;
import java.util.Date;
import java.util.Random;

/**
 * 关于字符串的帮助类
 */
public class StringUtil {
    private static Logger logger = Logger.getLogger(StringUtil.class);

    public static String empt = "";

    /**
     * 生成唯一号
     *
     * @return
     */
    public static String uniqueCode(String prefix, Long flag1, Long flag2) {
        Random rand = new Random();
        String flag1Str = "0000000000"
                + (flag1 == null ? rand.nextInt(9999) : flag1);
        flag1Str = flag1Str.substring(flag1Str.length() - 7);
        String flag2Str = "0000000000"
                + (flag2 == null ? rand.nextInt(9999) : flag2);
        flag2Str = flag2Str.substring(flag2Str.length() - 7);
        String time = DateUtil.date2String(new Date(), "yyMMddHHmmss");
        if (prefix == null)
            prefix = "";
        return new StringBuffer(prefix).append(time).append(flag1Str)
                .append(flag2Str).toString();
    }

    public static double toDouble(Object str, int def) {
        if (str == null) {
            return def;
        }
        if (str.toString().isEmpty()) {
            return def;
        }
        try {
            return Double.parseDouble(str.toString());
        } catch (Exception e) {
            logger.warn("数字转换失败", e);
            return def;
        }
    }

    public static int toInt(Object str, int def) {
        if (str == null) {
            return def;
        }
        if (str.toString().isEmpty()) {
            return def;
        }
        try {
            return Integer.parseInt(str.toString());
        } catch (Exception e) {
            logger.warn("数字转换失败", e);
            return def;
        }
    }

    public static Integer toInteger(Object str, Integer def) {
        if (str == null) {
            return def;
        }
        if (str.toString().isEmpty()) {
            return def;
        }
        try {
            return Integer.parseInt(str.toString());
        } catch (Exception e) {
            logger.warn("数字转换失败", e);
            return def;
        }
    }

    public static Date toDateTime(Object str,Date def){
        return toDate(str,"yyyy-MM-dd HH:mm:ss",def);
    }

    public static Date toDateTime(Object str){
        return toDate(str,"yyyy-MM-dd HH:mm:ss",null);
    }

    public static Date toDate(Object str, Date def) {
        return toDate(str,"yyyy-MM-dd",def);
    }

    public static Date toDate(Object str){
        return toDate(str,"yyyy-MM-dd HH:mm:ss",null);
    }

    public static Date toDate(Object str,String formart, Date def) {
        if (str == null) {
            return def;
        }
        if (str.toString().isEmpty()) {
            return def;
        }
        try {
            return DateUtil.string2Date(str.toString(), formart);
        } catch (ParseException e) {
            logger.warn("日期转换失败", e);
            return def;
        }
    }

    public static String toText(Object str) {
        if (str == null) {
            return empt;
        }
        return str.toString();
    }

    public static double toMoney(Object str, double def) {
        if (str == null) {
            return def;
        }
        if (str.toString().isEmpty()) {
            return def;
        }
        try {
            int moneyX = Integer.parseInt(str.toString());
            double money = moneyX / 100;
            return money;
        } catch (Exception e) {
            logger.warn("数字转换失败", e);
            return def;
        }
    }

    public static double toMoney(Object str) {
        if (str == null) {
            return 0;
        }
        if (str.toString().isEmpty()) {
            return 0;
        }
        try {
            int moneyX = Integer.parseInt(str.toString());
            double money = moneyX / 100;
            return money;
        } catch (Exception e) {
            logger.warn("数字转换失败", e);
        }
        return 0;
    }

    public static String toString(Object str) {
        if (hasEmpty(str)) return null;
        return str.toString();
    }

    public static String toString(Object str, String def) {
        if (hasEmpty(str)) return def;

        return str.toString();
    }

    public static boolean hasEmpty(Object headImg) {
        if (headImg == null || headImg.toString().trim().equals(empt)) {
            return true;
        }
        return false;
    }

}
