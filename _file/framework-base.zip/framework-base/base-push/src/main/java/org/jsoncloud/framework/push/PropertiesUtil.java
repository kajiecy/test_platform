package org.jsoncloud.framework.push;

/**
 * Created by Administrator on 2017/3/25.
 */
public class PropertiesUtil extends org.jsoncloud.framework.util.PropertiesUtil {

    /**************
     * 个推
     ****************/
    public static String getuiAppId() {
        return get("getui_app_id");
    }

    public static String getuiAppSecret() {
        return get("getui_app_secret");
    }

    public static String getuiAppKey() {
        return get("getui_app_key");
    }

    public static String getuiMasterSecret() {
        return get("getui_master_secret");
    }

    public static String getuiNotifyImg() {
        return get("getui_notify_img");
    }

    public static String getuiHostUrl() {
        return get("getui_host_url");
    }

    /*别名的关键参数*/
    public static String getuiAliasPrefix() {
        return get("getui_alias_prefix");
    }

}
