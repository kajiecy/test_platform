package org.jsoncloud.framework.web.request;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.jsoncloud.framework.constant.Constants;
import org.jsoncloud.framework.exception.ErrorEnum;
import org.jsoncloud.framework.exception.ProjectException;
import org.jsoncloud.framework.util.DateUtil;
import org.apache.log4j.Logger;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;

/**
 * 普通参数请求
 */
public class RequestKeyVal implements RequestData {

    @Override
    public String toString() {
        Map<String, String[]> param = request.getParameterMap();
        StringBuffer result = new StringBuffer();
        for (Map.Entry<String, String[]> one : param.entrySet()) {
            result.append(one.getKey() + ":" + Arrays.deepToString(one.getValue()));
        }
        return result.toString();
    }

    protected static Logger logger = Logger.getLogger(RequestKeyVal.class);
    private final HttpServletRequest request;

    public RequestKeyVal(HttpServletRequest requestOrWrapper) {
        if (requestOrWrapper == null) throw new NullPointerException(ErrorEnum.INVALID_NULL.getCode() + "");
        this.request = requestOrWrapper;
    }

    @Override
    public String[] getArrayMust(String name, String tip) {
        String[] result = getArray(name, true, tip);
        return result;
    }

    @Override
    public String[] getArrayNull(String name) {
        String[] result = getArray(name, false, "");
        return (result == null || result.length == 0) ? null : result;
    }

    /**
     * 获取数组 例如checkbOX
     *
     * @param name
     * @param isMust
     * @param msg
     * @return
     */
    public String[] getArray(String name, boolean isMust, String msg) {
        String[] data = request.getParameterValues(name);
        if (data == null && isMust) {
            throw new ProjectException(1002, msg, name + ":传入的数组不可为空");
        }
        return data;
    }


    @Override
    public Object getMust(String name, String tip) {
        Object result = get(name);
        if (result == null) {
            throw new ProjectException(ErrorEnum.INVALID_NULL.getCode(), tip, "存在空值" + name);
        }
        return result;
    }


    @Override
    public Object get(String name) {
        String val = request.getParameter(name);
        return val;
    }


    @Override
    public Integer getIntMust(String name, String tip) {
        return getInt(name, true, tip);
    }

    @Override
    public Integer getIntNull(String name) {
        return getIntDef(name, null);
    }


    @Override
    public Integer getIntDef(String name, Integer def) {
        Integer val = this.getInt(name, false, null);
        return val == null ? def : val;
    }


    @Override
    public Integer getInt(String name, boolean isMust, String tip) {
        String val = request.getParameter(name);
        if ((val == null || val.equals("")) && isMust) {
            throw new ProjectException(ErrorEnum.INVALID_NULL.getCode(), tip, name + "不可为空");
        } else if (val == null) {
            return null;
        }
        try {
            return Integer.parseInt(val);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            if (isMust) {
                throw new ProjectException(  ErrorEnum.INVALID_VALUE.getCode(), tip, name + "格式不正确," + e.getMessage());
            }
            return null;
        }
    }


    @Override
    public Long getLongMust(String name, String tip) {
        return getLong(name, true, tip);
    }


    @Override
    public Long getLongNull(String name) {
        return getLongDef(name, null);
    }


    @Override
    public Long getLongDef(String name, Long def) {
        Long val = getLong(name, false, null);
        return val == null ? def : val;
    }

    @Override
    public Long getLong(String name, boolean isMust, String tip) {
        String val = request.getParameter(name);
        if ((val == null || val.equals("")) && isMust) {
            throw new ProjectException(ErrorEnum.INVALID_NULL.getCode(), tip, name + "不可为空");
        } else if (val == null) {
            return null;
        }
        try {
            return Long.parseLong(val);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            if (isMust) {
                throw new ProjectException(ErrorEnum.INVALID_VALUE.getCode(), tip, name + "格式不正确," + e.getMessage());
            }
            return null;
        }
    }


    @Override
    public Double getDoubleNull(String name) {
        return getDoubleDef(name, null);
    }


    @Override
    public Double getDoubleDef(String name, Double def) {
        Double val = getDouble(name, false, null);
        return val == null ? def : val;
    }


    @Override
    public Double getDoubleMust(String name, String tip) {
        return getDouble(name, true, tip);
    }

    @Override
    public Double getDouble(String name, boolean isMust, String tip) {
        String val = request.getParameter(name);
        if ((val == null || val.equals("")) && isMust) {
            throw new ProjectException(ErrorEnum.INVALID_NULL.getCode(), tip, name + "不可为空");
        } else if (val == null) {
            return null;
        }
        try {
            return Double.parseDouble(val);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            if (isMust) {
                throw new ProjectException(ErrorEnum.INVALID_VALUE.getCode(), tip, name + "格式不正确," + e.getMessage());
            }
            return null;
        }
    }


    @Override
    public JSONArray getJSONArrayMust(String name, String tip) {
        return getJSONArray(name, true, tip);
    }

    @Override
    public JSONArray getJSONArrayNull(String name) {
        return getJSONArray(name, false, null);
    }

    /**
     * 上传的参数中包含值为JSONArray的参数
     *
     * @param name
     * @param isMust
     * @param tip
     * @return
     */
    @Override
    public JSONArray getJSONArray(String name, boolean isMust, String tip) {
        String val = request.getParameter(name);
        if ((val == null || val.isEmpty()) && isMust) {
            throw new ProjectException(ErrorEnum.INVALID_NULL.getCode(), tip, name + "不可为空");
        } else if (val == null) {
            return null;
        }
        try {
            JSONArray array = JSONArray.parseArray(val);
            if (isMust && array.isEmpty())
                throw new Exception();
            return array;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            if (isMust) {
                throw new ProjectException(ErrorEnum.INVALID_VALUE.getCode(), tip, name + "格式不正确," + e.getMessage());
            }
            return null;
        }
    }


    @Override
    public JSONObject getJSONMust(String name, String tip) {
        return getJSON(name, true, tip);
    }

    @Override
    public JSONObject getJSONNull(String name) {
        return getJSON(name, false, "");
    }

    /**
     * 上传的参数中包含值为JSON的参数
     *
     * @param name
     * @param isMust
     * @param tip
     * @return
     */
    @Override
    public JSONObject getJSON(String name, boolean isMust, String tip) {
        String val = request.getParameter(name);
        if ((val == null || val.isEmpty()) && isMust) {
            throw new ProjectException(ErrorEnum.INVALID_NULL.getCode(), tip, name + "不可为空");
        } else if (val == null) {
            return null;
        }
        try {
            return (JSONObject) JSONObject.parse(val);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            if (isMust) {
                throw new ProjectException(ErrorEnum.INVALID_VALUE.getCode(), tip, name + "格式不正确," + e.getMessage());
            }
            return null;
        }
    }


    @Override
    public String getStringMust(String name, String tip) {
        return getString(name, true, tip);
    }


    @Override
    public String getStringDef(String name, String def) {
        String val = getString(name, false, null);
        return val == null ? def : val;
    }


    @Override
    public String getStringNull(String name) {
        String val = getString(name, false, null);
        return "".equals(val) ? null : val;
    }

    @Override
    public String getString(String name, boolean isMust, String tip) {
        String val = request.getParameter(name);
        if ((val == null || "".equals(val)) && isMust) {
            throw new ProjectException(ErrorEnum.INVALID_NULL.getCode(), tip, name + "不可为空");
        } else if (val == null) {
            return null;
        }
        return val;
    }


    @Override
    public Date getDatetimeMust(String name, String tip) {
        return getDatetime(name, true, tip);
    }


    @Override
    public Date getDatetimeNull(String name) {
        return getDatetime(name, false, null);
    }


    @Override
    public Date getDatetimeDef(String name, Date def) {
        Date val = getDatetime(name, false, null);
        return val == null ? def : val;
    }


    @Override
    public Date getDatetime(String name, boolean isMust, String tip) {
        String str = this.getString(name, isMust, tip);
        if (str == null)
            return null;
        try {
            return DateUtil.string2Date(str);
        } catch (ParseException e) {
            logger.error(e.getMessage(), e);
            if (isMust) {
                throw new ProjectException(ErrorEnum.INVALID_VALUE.getCode(), tip, name + "格式不正确," + e.getMessage());
            }
            return null;
        }
    }


    @Override
    public Date getDateMust(String name, String tip) {
        return getDate(name, true, tip);
    }


    @Override
    public Date getDateNull(String name) {
        return getDate(name, false, null);
    }


    @Override
    public Date getDateDef(String name, Date def) {
        Date val = getDate(name, false, null);
        return val == null ? def : val;
    }


    @Override
    public Date getDate(String name, boolean isMust, String tip) {
        String str = this.getString(name, isMust, tip);
        if (str == null)
            return null;
        try {
            return DateUtil.string2Date(str, "yyyy-MM-dd");
        } catch (ParseException e) {
            logger.error(e.getMessage(), e);
            if (isMust) {
                throw new ProjectException(ErrorEnum.INVALID_VALUE.getCode(), tip, name + "格式不正确," + e.getMessage());
            }
            return null;
        }
    }


}
