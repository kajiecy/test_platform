package org.jsoncloud.framework.web.interceptor;

import org.apache.log4j.Logger;
import org.jsoncloud.framework.constant.Constants;
import org.jsoncloud.framework.exception.ErrorEnum;
import org.jsoncloud.framework.exception.ProjectException;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 登录拦截器
 * Created by Bames on 2016/8/4.
 */
public class LoginInterceptor extends HandlerInterceptorAdapter {

    private static Logger logger = Logger.getLogger(LoginInterceptor.class);

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        Object loginUser = request.getSession().getAttribute(Constants.SESSION_LOGIN_USER);
        if (loginUser == null) {
            logger.info("## 用户未登录，拦截路径：" + request.getRequestURL() + "?" + request.getQueryString());
            throw new ProjectException(ErrorEnum.USER_NOT_LOGIN.getCode(),"会话已过期，请重新登录", "session无用户");
        }
        return super.preHandle(request, response, handler);
    }

}
