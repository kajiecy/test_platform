package org.jsoncloud.framework.web.util;

import org.jsoncloud.framework.constant.Constants;
import org.jsoncloud.framework.exception.ErrorEnum;
import org.jsoncloud.framework.exception.ProjectException;

import java.util.regex.Pattern;

/**
 * 校验器：利用正则表达式校验邮箱、手机号等
 *
 * @author: chenb
 */
public class ValidatorUtil {
    /**
     * 正则表达式：验证用户名
     */
    public static final String REGEX_USERNAME = "^[a-zA-Z]\\w{5,17}$";

    /**
     * 正则表达式：验证密码
     */
    public static final String REGEX_PASSWORD = "^[a-zA-Z0-9]{6,16}$";

    /**
     * 正则表达式：验证手机号
     */
    public static final String REGEX_MOBILE = "^\\d{11}$";

    /**
     * 正则表达式：验证邮箱
     */
    public static final String REGEX_EMAIL = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";

    /**
     * 正则表达式：验证汉字
     */
    public static final String REGEX_CHINESE = "^[\u4e00-\u9fa5]{0,}$";

    /**
     * 正则表达式：验证身份证
     */
    public static final String REGEX_ID_CARD = "^(\\d{15}$|^\\d{18}$|^\\d{17}(\\d|X|x))$";

    /**
     * 正则表达式：验证URL
     */
    public static final String REGEX_URL = "(http|ftp|https):\\/\\/[\\w\\-_]+(\\.[\\w\\-_]+)+([\\w\\-\\.,@?^=%&amp;:/~\\+#]*[\\w\\-\\@?^=%&amp;/~\\+#])?";

    /**
     * 正则表达式：验证IP地址
     */
    public static final String REGEX_IP_ADDR = "(25[0-5]|2[0-4]\\d|[0-1]\\d{2}|[1-9]?\\d)";

    /**
     * 校验用户名
     *
     * @param username
     * @return 校验通过返回true，否则返回false
     */
    public static boolean isUsername(String username) {
        return Pattern.matches(REGEX_USERNAME, username);
    }

    /**
     * 校验密码:6~16位字母、数字
     *
     * @param password
     * @return 校验通过返回true，否则返回false
     */
    public static boolean isPassword(String password) {
        return Pattern.matches(REGEX_PASSWORD, password);
    }

    /**
     * 校验手机号
     *
     * @param mobile
     * @return 校验通过返回true，否则返回false
     */
    public static boolean isMobile(String mobile) {
        return Pattern.matches(REGEX_MOBILE, mobile);
    }

    /**
     * 强制校验手机号，不匹配则抛出异常
     *
     * @param mobile
     * @param tip
     */
    public static void assertMobile(String mobile, String tip) {
        if (!isMobile(mobile)) {
            throw new ProjectException(ErrorEnum.INVALID_TYPE.getCode(), tip);
        }
    }

    /**
     * 校验邮箱
     *
     * @param email
     * @return 校验通过返回true，否则返回false
     */
    public static boolean isEmail(String email) {
        return Pattern.matches(REGEX_EMAIL, email);
    }

    /**
     * 强制校验邮箱，不匹配则抛出异常
     *
     * @param email
     * @param tip
     */
    public static void assertEmail(String email, String tip) {
        if (!isEmail(email)) {
            throw new ProjectException(ErrorEnum.INVALID_TYPE.getCode(), tip);
        }
    }

    /**
     * 校验汉字
     *
     * @param chinese
     * @return 校验通过返回true，否则返回false
     */
    public static boolean isChinese(String chinese) {
        return Pattern.matches(REGEX_CHINESE, chinese);
    }

    /**
     * 校验身份证
     *
     * @param idCard
     * @return 校验通过返回true，否则返回false
     */
    public static boolean isIDCard(String idCard) {
        return Pattern.matches(REGEX_ID_CARD, idCard);
    }

    /**
     * 强制校身份证，不匹配则抛出异常
     *
     * @param idCard
     * @param tip
     */
    public static void assertIDCard(String idCard, String tip) {
        if (!isIDCard(idCard)) {
            throw new ProjectException(ErrorEnum.INVALID_TYPE.getCode(), tip);
        }
    }

    /**
     * 校验URL
     *
     * @param url
     * @return 校验通过返回true，否则返回false
     */
    public static boolean isUrl(String url) {
        return Pattern.matches(REGEX_URL, url);
    }

    /**
     * 强制校URL，不匹配则抛出异常
     *
     * @param url
     * @param tip
     */
    public static void assertUrl(String url, String tip) {
        if (!isUrl(url)) {
            throw new ProjectException(ErrorEnum.INVALID_TYPE.getCode(), tip);
        }
    }

    /**
     * 校验IP地址
     *
     * @param ipAddr
     * @return
     */
    public static boolean isIPAddr(String ipAddr) {
        return Pattern.matches(REGEX_IP_ADDR, ipAddr);
    }

    /**
     * 强制校IP地址，不匹配则抛出异常
     *
     * @param ipAddr
     * @param tip
     */
    public static void assertIPAddr(String ipAddr, String tip) {
        if (!isIPAddr(ipAddr)) {
            throw new ProjectException(ErrorEnum.INVALID_TYPE.getCode(), tip);
        }
    }

    public static void main(String[] args) {
        String value = "http://regxlib.com/Default.aspx";
        String value2 = "http://electronics.cnet.com/electronics/0-6342366-8-8994967-1.html";
        String value3 = "http://127.0.0.1:8080/test.html";

        System.out.println(ValidatorUtil.isUrl(value));
        System.out.println(ValidatorUtil.isUrl(value2));
        System.out.println(ValidatorUtil.isUrl(value3));
        System.out.println(ValidatorUtil.isUsername(value));
        System.out.println(ValidatorUtil.isChinese(value));
        System.out.println(ValidatorUtil.isChinese("你好"));

        System.out.println(ValidatorUtil.isIDCard("34050419810914003X"));
    }
}
