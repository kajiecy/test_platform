package org.jsoncloud.framework.web.util;

import org.jsoncloud.framework.constant.Constants;
import org.jsoncloud.framework.exception.CommonException;
import org.jsoncloud.framework.exception.ErrorEnum;
import org.jsoncloud.framework.exception.ProjectException;

import javax.servlet.http.HttpServletRequest;

public class ParamUtil {

    /**
     * 非空参数验证
     *
     * @throws CommonException
     */
    public static void assertNotNull(HttpServletRequest request, String tip, String... names) {
        for (String name : names) {
            String val = request.getParameter(name);
            if (val == null || "".equals(val.trim())) {
                throw new ProjectException( ErrorEnum.INVALID_NULL.getCode(), tip, "name ["
                        + name + "] is empty!");
            }
        }
    }

    /**
     * 验证多个参数必须存在至少一个
     *
     * @param request
     * @param params
     * @throws CommonException
     */
    public static void assertEither(HttpServletRequest request, String tip, String... params) {
        StringBuffer names = new StringBuffer();
        for (String one : params) {
            String val = request.getParameter(one);
            if (val != null && !"".equals(val.trim())) {
                return;
            }
            names.append(one + ",");
        }
        throw new ProjectException(ErrorEnum.INVALID_NULL.getCode(), tip, "names [" + names
                + "] is empty!");
    }

    /**
     * long类型参数验证
     *
     * @param request
     * @param names
     */
    public static void assertLong(HttpServletRequest request, String tip, String... names) {
        for (String name : names) {
            String val = request.getParameter(name);
            if (val != null) {
                Long.parseLong(val);
            }
        }
    }

    public static void assertInt(HttpServletRequest request, String tip, String... names) {
        for (String name : names) {
            String val = request.getParameter(name);
            if (val != null) {
                Integer.parseInt(val);
            }
        }
    }

    public static void assertDouble(HttpServletRequest request, String tip, String... names) {
        for (String name : names) {
            String val = request.getParameter(name);
            if (val != null) {
                Double.parseDouble(val);
            }
        }
    }

}
