package org.jsoncloud.framework.web.util;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by Bames on 2016/9/18.
 */
public class WebUtil {

    /**
     * java目录
     */
    public static String getJavaHome() {
        return System.getProperty("java.home");
    }

    /**
     * 获取用户目录
     *
     * @return
     */
    public static String getUserHome() {
        return System.getProperty("user.home");
    }


    /**
     * 访问项目基路径
     *
     * @param request
     * @return
     */
    public static String getWebBasePath(HttpServletRequest request) {
        return request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath() + "/";
    }


}
