package org.jsoncloud.framework.web.controller;

import org.apache.log4j.Logger;
import org.jsoncloud.framework.constant.Constants;
import org.jsoncloud.framework.exception.ErrorEnum;
import org.jsoncloud.framework.exception.ProjectException;
import org.jsoncloud.framework.mybatis.MybatisDao;
import org.jsoncloud.framework.web.response.ResponseMap;
import org.springframework.beans.TypeMismatchException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

/**
 * 基础controller封装部分方法。此controller为框架基类。
 * 建议使用时，在项目中继承此类形成项目自己的基类，
 * 这样在适当的情况下，可以很方便地重写BaseController中的方法。
 *
 * @author Bames
 */
public abstract class BaseController {

    protected Logger logger = Logger.getLogger(getClass());

    @Resource(name = "mybatisDao")
    protected MybatisDao mybatisDao;

    /**
     * 异常处理栈:所有方法抛出的 Exception 都会交由此处处理,子类也可以自己重写此方法
     *
     * @param request
     * @param response
     * @param e
     * @return
     */
    @ResponseBody
    @ExceptionHandler(Exception.class)
    public Map<String, Object> handleException(HttpServletRequest request, HttpServletResponse response, Exception e) {
        logger.error("##################### 处理异常：" + e.getMessage() + ",-->" + e.getClass().getName(), e);
        if (e instanceof ProjectException) {//程序中招聘的异常
            ProjectException ae = (ProjectException) e;
            return ResponseMap.error(ae.getCode(), ae.getTip(), ae.getError()).result();
        } else if (e instanceof MissingServletRequestParameterException) {//参数为空
            return ResponseMap.error(ErrorEnum.INVALID_NULL.getCode(), ErrorEnum.INVALID_NULL.getDescribeCn(), e.getMessage()).result();
        } else if (e instanceof TypeMismatchException) {//参数类型不匹配,通常是数值类型不对
            return ResponseMap.error(ErrorEnum.INVALID_TYPE.getCode(), ErrorEnum.INVALID_TYPE.getDescribeCn(), e.getMessage()).result();
        }
        return ResponseMap.error(ErrorEnum.UNKNOWN.getCode(), ErrorEnum.UNKNOWN.getDescribeCn(), e.getMessage()).result();
    }

    /**
     * 获取当前登录的用户
     *
     * @param session
     * @return
     */
    protected Map<String, Object> getLoginUser(HttpSession session) {
        return (Map<String, Object>) session.getAttribute(Constants.SESSION_LOGIN_USER);
    }

    protected Map<String, Object> getCondition() {
        return new HashMap<String, Object>();
    }

}
