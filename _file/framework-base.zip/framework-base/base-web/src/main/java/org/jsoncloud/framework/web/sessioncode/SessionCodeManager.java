package org.jsoncloud.framework.web.sessioncode;

import com.alibaba.fastjson.JSON;
import org.apache.log4j.Logger;
import org.jsoncloud.framework.sms.chuangl.SmsChuangLanUtil;
import org.jsoncloud.framework.util.DateUtil;
import org.jsoncloud.framework.util.PropertiesUtil;
import org.jsoncloud.framework.util.RandUtil;
import org.jsoncloud.framework.util.StringUtil;
import org.jsoncloud.framework.verifcode.sms.SmsCodeBean;
import org.jsoncloud.framework.verifcode.sms.SmsCodeManager;

import javax.servlet.http.HttpSession;
import java.text.ParseException;
import java.util.Date;

/**
 * session 验证码管理器
 * Created by Bames on 2016/8/2.
 */
public class SessionCodeManager extends SmsCodeManager {
    private static Logger logger = Logger.getLogger(SessionCodeManager.class);

    /**
     * 建立 一个新的session-code或将session 中的code 有效期刷新
     *
     * @param session
     * @param phone
     * @param sessionKey
     * @return
     */
    public static SmsCodeBean buildSessionCode(HttpSession session, String phone, String codeType, String sessionKey) {
        SmsCodeBean bean = (SmsCodeBean) session.getAttribute(sessionKey);
        Integer smsTime = getEnableTime();
        long delay = (smsTime == null ? 10 : smsTime) * 60 * 1000;
        String end_time = DateUtil.getDateTimeStrForAddTimeInMillis(new Date(), delay);
        Date endTime = null;
        try {
            endTime = DateUtil.string2Date(end_time);
        } catch (ParseException e) {
            logger.error("###时间转换失败<" + end_time + ">");
        }
        if (bean != null) {
            bean.setPhone(phone);
            bean.setCodeType(codeType);
            bean.setValidTime(smsTime);
            bean.setEndTime(endTime);
            //如果验证码的有效期不是随着每次请求而刷新的，则直接注释掉下面这句代码即可
        } else {
            bean = new SmsCodeBean(phone, RandUtil.randomInt(4) + "", codeType);
            bean.setValidTime(smsTime);
            bean.setEndTime(endTime);
        }
        session.setAttribute(sessionKey, bean);
        return bean;
    }

    /**
     * 获取session中的验证码
     *
     * @param session
     * @param sessionKey
     * @return
     */
    public static SmsCodeBean getSessionCode(HttpSession session, String sessionKey) {
        Object obj = session.getAttribute(sessionKey);
        return (obj instanceof SmsCodeBean) ? (SmsCodeBean) obj : null;
    }

    /**
     * 移除session中的验证码
     *
     * @param session
     * @param sessionKey
     * @return session中移除掉的验证码sessionCode
     */
    public static SmsCodeBean removeSessionCode(HttpSession session, String sessionKey) {
        SmsCodeBean sessionCode = getSessionCode(session, sessionKey);
        if (sessionCode != null) {
            session.removeAttribute(sessionKey);
        }
        return sessionCode;
    }

    /**
     * 校验验证码
     *
     * @return
     */
    public static boolean compareCode(HttpSession session, String sessionKey, String reqcode, String phone, String codeType, String sport) {
        SmsCodeBean bean = getSessionCode(session, sessionKey);
        logger.debug("【SMS验证码对比】:" + JSON.toJSONString(bean));
        if (bean != null
                && bean.getCode().equals(reqcode)
                && (bean.getPhone() == null || bean.getPhone().equals(phone))
                && (bean.getCodeType() == null || bean.getCodeType().equals(codeType))
                && (bean.getSpot() == null || bean.getSpot().equals(sport))
                ) {
            removeSessionCode(session, sessionKey);
            return true;
        }
        return false;
    }

    public static boolean compareCode(HttpSession session, String sessionKey, String reqcode, String phone, String codeType) {
        return compareCode(session, sessionKey, reqcode, phone, codeType, null);
    }

    public static boolean compareCode(HttpSession session, String sessionKey, String reqcode, String phone) {
        return compareCode(session, sessionKey, reqcode, phone, null, null);
    }

    public static boolean compareCode(HttpSession session, String sessionKey, String reqcode) {
        return compareCode(session, sessionKey, reqcode, null, null);
    }

}
