package org.jsoncloud.framework.web.request;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import org.jsoncloud.framework.constant.Constants;
import org.jsoncloud.framework.exception.ErrorEnum;
import org.jsoncloud.framework.exception.ProjectException;
import org.jsoncloud.framework.util.DateUtil;
import org.apache.log4j.Logger;
import org.jsoncloud.framework.util.StringUtil;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.Date;

/**
 * 将json包装在参数请求体内的请求方式
 */
public class RequestBodyJSON implements RequestData {

    /**
     * 存储在setAttribute 中的缓存的KEY
     */
    private String attrubit_cache_key = "ORG_JSONCLOUD_FRAMEWORK_BASE_WEB_CACHE_REQUEST_DATA";

    @Override
    public String toString() {
        return "RequestData [json=" + json + "]";
    }

    protected static Logger logger = Logger.getLogger(RequestBodyJSON.class);

    private JSONObject json;
    private JSONArray jsonArray;

    /**
     * 初始化读取request 的流
     *
     * @param request 流
     */
    public RequestBodyJSON(HttpServletRequest request) {
        String inputStr = StringUtil.toString(request.getAttribute(attrubit_cache_key));
        InputStream in = null;
        try {
            if (inputStr == null) {
                request.setCharacterEncoding("UTF-8");
                in = request.getInputStream();
                byte[] total = new byte[0];// 总数据
                byte[] old;// 临时数组
                byte[] buffer = new byte[1024];// 缓冲区
                for (int len = in.read(buffer); len != -1; len = in.read(buffer)) {
                    old = total;
                    total = new byte[total.length + len];
                    System.arraycopy(old, 0, total, 0, old.length);
                    System.arraycopy(buffer, 0, total, old.length, len);
                }
                inputStr = new String(total, "UTF-8");
                StringBuffer info = new StringBuffer();
                info.append(" ... REQUEST BODY ... 请求体 :" + System.getProperty("line.separator")).append(inputStr).append(System.getProperty("line.separator"));
                inputStr = _wrapRequestStr(inputStr);
                info.append(" ... REQUEST BODY [ parsed ] ... 解析后的请求体 : " + System.getProperty("line.separator")).append(inputStr)
                        .append(System.getProperty("line.separator"));
                logger.info("## ... REQUEST DATA ... 解析用户请求体 :" + System.getProperty("line.separator") + info);
                request.setAttribute(attrubit_cache_key, inputStr);
            }
            Object objson = JSON.parse(inputStr);
            if (objson instanceof JSONObject) {
                this.json = (JSONObject) objson;
            } else if (objson instanceof JSONArray) {
                this.jsonArray = (JSONArray) objson;
            } else if (objson == null) {
                logger.warn("## ");
            } else {
                throw new ProjectException(ErrorEnum.SYSTEM.getCode(), "提交数据异常", "您的数据格式异常，无法解析");
            }
        } catch (JSONException e) {
            logger.error("## RequestData 获取json参数异常！", e);
            throw new ProjectException(ErrorEnum.SYSTEM.getCode(), "非法输入", "输入json无法解析");
        } catch (IOException e) {
            logger.error("## RequestData 获取参数失败！", e);
            throw new ProjectException(ErrorEnum.SYSTEM.getCode(), "获取参数失败", e.getMessage());
        } finally {
            try {
                if (in != null)
                    in.close();
            } catch (IOException e) {
                logger.error("## RequestData 流关闭失败！", e);
            }
        }
    }

    /**
     * 包装请求:在此对请求体内容做特殊处理
     */
    private String _wrapRequestStr(String inputStr) {
        return inputStr;
    }

    public JSONArray getArrayMust(String name, String tip) {
        if (this.jsonArray == null) {
            throw new ProjectException( ErrorEnum.INVALID_NULL.getCode(), tip, "request数据数组为空");
        }
        return this.jsonArray;
    }

    @Override
    public JSONArray getArrayNull(String name) {
        return this.jsonArray;
    }


    @Override
    public Object getMust(String name, String tip) {
        Object result = get(name);
        if (this.json == null) {
            throw new ProjectException(ErrorEnum.INVALID_NULL.getCode(), tip, "存在空值" + name);
        }
        return result;
    }

    @Override
    public Object get(String name) {
        return (this.json == null) ? null : json.get(name);
    }


    @Override
    public Integer getIntMust(String name, String tip) {
        return getInt(name, true, tip);
    }

    @Override
    public Integer getIntNull(String name) {
        return getIntDef(name, null);
    }


    @Override
    public Integer getIntDef(String name, Integer def) {
        Integer val = this.getInt(name, false, null);
        return val == null ? def : val;
    }


    @Override
    public Integer getInt(String name, boolean isMust, String tip) {
        if ((this.json == null || json.get(name) == null || json.get(name).equals("")) && isMust) {
            throw new ProjectException(ErrorEnum.INVALID_NULL.getCode(), tip, name + "不可为空");
        } else if (this.json == null) {
            return null;
        }
        try {
            return json.getInteger(name);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            if (isMust) {
                throw new ProjectException(ErrorEnum.INVALID_VALUE.getCode(), tip, name + "格式不正确," + e.getMessage());
            }
            return null;
        }
    }


    @Override
    public Long getLongMust(String name, String tip) {
        return getLong(name, true, tip);
    }


    @Override
    public Long getLongNull(String name) {
        return getLongDef(name, null);
    }


    @Override
    public Long getLongDef(String name, Long def) {
        Long val = getLong(name, false, null);
        return val == null ? def : val;
    }

    @Override
    public Long getLong(String name, boolean isMust, String tip) {
        if ((this.json == null || json.get(name) == null || json.get(name).equals("")) && isMust) {
            throw new ProjectException(ErrorEnum.INVALID_NULL.getCode(), tip, name + "不可为空");
        } else if (this.json == null) {
            return null;
        }
        try {
            return json.getLong(name);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            if (isMust) {
                throw new ProjectException(ErrorEnum.INVALID_VALUE.getCode(), tip, name + "格式不正确," + e.getMessage());
            }
            return null;
        }
    }


    @Override
    public Double getDoubleNull(String name) {
        return getDoubleDef(name, null);
    }


    @Override
    public Double getDoubleDef(String name, Double def) {
        Double val = getDouble(name, false, null);
        return val == null ? def : val;
    }


    @Override
    public Double getDoubleMust(String name, String tip) {
        return getDouble(name, true, tip);
    }

    @Override
    public Double getDouble(String name, boolean isMust, String tip) {
        if ((this.json == null || json.get(name) == null || json.get(name).equals("")) && isMust) {
            throw new ProjectException(ErrorEnum.INVALID_NULL.getCode(), tip, name + "不可为空");
        } else if (this.json == null) {
            return null;
        }
        try {
            return json.getDouble(name);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            if (isMust) {
                throw new ProjectException(ErrorEnum.INVALID_VALUE.getCode(), tip, name + "格式不正确," + e.getMessage());
            }
            return null;
        }
    }


    @Override
    public JSONArray getJSONArrayMust(String name, String tip) {
        return getJSONArray(name, true, tip);
    }

    @Override
    public JSONArray getJSONArrayNull(String name) {
        return getJSONArray(name, false, null);
    }

    @Override
    public JSONArray getJSONArray(String name, boolean isMust, String tip) {
        if ((this.json == null || json.get(name) == null) && isMust) {
            throw new ProjectException(ErrorEnum.INVALID_NULL.getCode(), tip, name + "不可为空");
        } else if (this.json == null) {
            return null;
        }
        try {
            JSONArray array = json.getJSONArray(name);
            if (isMust && array.isEmpty())
                throw new Exception();
            return array;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            if (isMust) {
                throw new ProjectException(ErrorEnum.INVALID_VALUE.getCode(), tip, name + "格式不正确," + e.getMessage());
            }
            return null;
        }
    }


    @Override
    public JSONObject getJSONMust(String name, String tip) {
        return getJSON(name, true, tip);
    }

    @Override
    public JSONObject getJSONNull(String name) {
        return getJSON(name, false, "");
    }

    @Override
    public JSONObject getJSON(String name, boolean isMust, String tip) {
        if ((this.json == null || json.get(name) == null) && isMust) {
            throw new ProjectException(ErrorEnum.INVALID_NULL.getCode(), tip, name + "不可为空");
        } else if (this.json == null) {
            return null;
        }
        try {
            return json.getJSONObject(name);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            if (isMust) {
                throw new ProjectException(ErrorEnum.INVALID_VALUE.getCode(), tip, name + "格式不正确," + e.getMessage());
            }
            return null;
        }
    }


    @Override
    public String getStringMust(String name, String tip) {
        return getString(name, true, tip);
    }


    @Override
    public String getStringDef(String name, String def) {
        String val = getString(name, false, null);
        return val == null ? def : val;
    }


    @Override
    public String getStringNull(String name) {
        String val = getString(name, false, null);
        return "".equals(val) ? null : val;
    }

    @Override
    public String getString(String name, boolean isMust, String tip) {
        if ((this.json == null || json.get(name) == null || "".equals(json.get(name))) && isMust) {
            throw new ProjectException(ErrorEnum.INVALID_NULL.getCode(), tip, name + "不可为空");
        } else if (this.json == null) {
            return null;
        }
        try {
            return json.getString(name);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            if (isMust) {
                throw new ProjectException( ErrorEnum.INVALID_VALUE.getCode(), tip, name + "格式不正确," + e.getMessage());
            }
            return null;
        }
    }


    @Override
    public Date getDatetimeMust(String name, String tip) {
        return getDatetime(name, true, tip);
    }


    @Override
    public Date getDatetimeNull(String name) {
        return getDatetime(name, false, null);
    }


    @Override
    public Date getDatetimeDef(String name, Date def) {
        Date val = getDatetime(name, false, null);
        return val == null ? def : val;
    }


    @Override
    public Date getDatetime(String name, boolean isMust, String tip) {
        String str = this.getString(name, isMust, tip);
        if (str == null)
            return null;
        try {
            return DateUtil.string2Date(str);
        } catch (ParseException e) {
            logger.error(e.getMessage(), e);
            if (isMust) {
                throw new ProjectException(ErrorEnum.INVALID_VALUE.getCode(), tip, name + "格式不正确," + e.getMessage());
            }
            return null;
        }
    }


    @Override
    public Date getDateMust(String name, String tip) {
        return getDate(name, true, tip);
    }


    @Override
    public Date getDateNull(String name) {
        return getDate(name, false, null);
    }


    @Override
    public Date getDateDef(String name, Date def) {
        Date val = getDate(name, false, null);
        return val == null ? def : val;
    }


    @Override
    public Date getDate(String name, boolean isMust, String tip) {
        String str = this.getString(name, isMust, tip);
        if (str == null)
            return null;
        try {
            return DateUtil.string2Date(str, "yyyy-MM-dd");
        } catch (ParseException e) {
            logger.error(e.getMessage(), e);
            if (isMust) {
                throw new ProjectException(ErrorEnum.INVALID_VALUE.getCode(), tip, name + "格式不正确," + e.getMessage());
            }
            return null;
        }
    }


}
