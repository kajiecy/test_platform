package org.jsoncloud.framework.web.response;

import com.alibaba.fastjson.JSONObject;
import org.jsoncloud.framework.exception.ErrorEnum;

import java.util.HashMap;
import java.util.Map;

/**
 * 对结果集的封装
 */
public class ResponseMap {

    private Map<String, Object> result;
    private Map<String, Object> data;
    private int code;

    private final String CODE = "code";
    private final String DATA = "data";
    private final String MESSAGE = "message";
    private final String ERROR = "error";

    private ResponseMap(int code) {
        result = new HashMap<String, Object>();
        data = new HashMap<String, Object>();
        this.code = code;
        result.put(CODE, code);
        result.put(DATA, data);
    }

    public static ResponseMap success(String tip) {
        return new ResponseMap(0).setTip(tip);
    }

    public static ResponseMap error(String tip) {
        return new ResponseMap(ErrorEnum.SYSTEM.getCode()).setTip(tip);
    }

    public static ResponseMap error(int errCode, String tip) {
        return new ResponseMap(errCode).setTip(tip);
    }

    public static ResponseMap error(int errCode, String tip, String errMsg) {
        return error(errCode, tip).setErrMsg(errMsg);
    }

    public ResponseMap setTip(String tip) {
        this.result.put(MESSAGE, tip);
        return this;
    }

    public ResponseMap setErrMsg(String errMsg) {
        this.result.put(ERROR, errMsg);
        return this;
    }

    /**
     * 添加data数据
     *
     * @param key
     * @param value
     * @return
     */
    public ResponseMap data(String key, Object value) {
        if (key != null && value != null) {
            this.data.put(key, value);
        }
        return this;
    }

    /**
     * 批量添加data数据
     *
     * @param alldata
     * @return
     */
    public ResponseMap dataAll(Map<String, Object> alldata) {
        if (alldata != null && alldata.size() > 0) {
            this.data.putAll(alldata);
        }
        return this;
    }

    public Map<String, Object> result() {
        return result;
    }

    public JSONObject resultJSON() {
        return new JSONObject(this.result);
    }

    public int getCode() {
        return this.code;
    }

}
