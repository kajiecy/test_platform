package org.jsoncloud.framework.web.request;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.util.Date;

/**
 * 请求参数的封装处理
 * Created by Bames on 2016/8/12.
 */
public interface RequestData {

    /**
     * 获取请求参数作为JSONArray的请求体方式的值
     *
     * @param tip
     * @return
     */
    <T> T getArrayMust(String name, String tip);

    /**
     * 获取请求参数作为JSONArray的请求体方式的值
     *
     * @return
     */
    <T> T getArrayNull(String name);

    /**
     * 不可空
     *
     * @param name
     * @param tip  参数为空时异常提示
     * @return
     */
    Object getMust(String name, String tip);

    /**
     * 可空
     */
    Object get(String name);

    /**
     * 不可空参数
     *
     * @param name
     * @return
     */
    Integer getIntMust(String name, String tip);

    Integer getIntNull(String name);

    /**
     * @param name
     * @param def  默认值
     * @return
     */
    Integer getIntDef(String name, Integer def);

    /**
     * 获取参数
     *
     * @param name
     * @return
     */
    Integer getInt(String name, boolean isMust, String tip);

    /**
     * 获取不可空参数，参数空时抛出异常
     *
     * @param name
     * @param tip  用户异常信息
     * @return
     */
    Long getLongMust(String name, String tip);

    /**
     * 可空参数
     *
     * @param name
     * @return
     */
    Long getLongNull(String name);

    /**
     * @param name
     * @param def  默认值
     * @return
     */
    Long getLongDef(String name, Long def);

    Long getLong(String name, boolean isMust, String tip);

    /**
     * 可空参数
     *
     * @param name
     * @return
     */
    Double getDoubleNull(String name);

    /**
     * @param name
     * @param def  默认值
     * @return
     */
    Double getDoubleDef(String name, Double def);

    /**
     * 获取不可空参数，参数空时抛出异常
     *
     * @param name
     * @param tip  用户异常信息
     * @return
     */
    Double getDoubleMust(String name, String tip);

    Double getDouble(String name, boolean isMust, String tip);

    /**
     * 获取不可空参数，参数空时抛出异常
     *
     * @param name
     * @param tip  用户异常信息
     * @return
     */
    JSONArray getJSONArrayMust(String name, String tip);

    JSONArray getJSONArrayNull(String name);

    JSONArray getJSONArray(String name, boolean isMust, String tip);

    /**
     * 获取不可空参数，参数空时抛出异常
     *
     * @param name
     * @param tip  用户异常信息
     * @return
     */
    JSONObject getJSONMust(String name, String tip);

    JSONObject getJSONNull(String name);

    JSONObject getJSON(String name, boolean isMust, String tip);

    /**
     * 获取不可空参数，参数空时抛出异常
     *
     * @param name
     * @param tip  异常时用户提示
     * @return
     */
    String getStringMust(String name, String tip);

    /**
     * @param name
     * @param def  默认值
     * @return
     */
    String getStringDef(String name, String def);

    /**
     * 获取可空的string, 如果string值是空字符串“”，则也返回null
     *
     * @param name
     * @return
     */
    String getStringNull(String name);

    String getString(String name, boolean isMust, String tip);

    /**
     * yyyy-MM-dd HH:mm:ss
     *
     * @param name
     * @param tip
     * @return
     */
    Date getDatetimeMust(String name, String tip);

    /**
     * yyyy-MM-dd HH:mm:ss
     *
     * @param name
     * @return
     */
    Date getDatetimeNull(String name);

    /**
     * yyyy-MM-dd HH:mm:ss
     *
     * @param name
     * @param def  默认值
     * @return
     */
    Date getDatetimeDef(String name, Date def);

    /**
     * yyyy-MM-dd HH:mm:ss
     *
     * @param name
     * @param isMust
     * @param tip
     * @return
     */
    Date getDatetime(String name, boolean isMust, String tip);

    /**
     * yyyy-MM-dd
     *
     * @param name
     * @param tip
     * @return
     */
    Date getDateMust(String name, String tip);

    /**
     * yyyy-MM-dd
     *
     * @param name
     * @return
     */
    Date getDateNull(String name);

    /**
     * yyyy-MM-dd
     *
     * @param name
     * @param def
     * @return
     */
    Date getDateDef(String name, Date def);

    /**
     * yyyy-MM-dd
     *
     * @param name
     * @param isMust
     * @return
     */
    Date getDate(String name, boolean isMust, String tip);
}
