package org.jsoncloud.framework.web.sessioncode;

import org.jsoncloud.framework.util.DateUtil;
import org.jsoncloud.framework.util.PropertiesUtil;
import org.junit.Test;

import java.text.ParseException;
import java.util.Date;

import static org.junit.Assert.*;

/**
 * Created by Administrator on 2017/5/21.
 */
public class SessionCodeManagerTest {
    @Test
    public void buildSessionCode() throws Exception {


    }

}