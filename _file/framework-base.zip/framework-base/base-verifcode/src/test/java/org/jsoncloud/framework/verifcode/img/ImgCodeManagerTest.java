package org.jsoncloud.framework.verifcode.img;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import static org.junit.Assert.*;

/**
 * Created by Administrator on 2017/3/27.
 */
@Ignore
public class ImgCodeManagerTest {
    @Before
    public void setUp() throws Exception {

    }

    @Test
    public void sendImgCode() throws Exception {

        /*ImgCodeManager imgCodeManager = new ImgCodeManager() {
            @Override
            public String sendImgCode(OutputStream os) throws IOException {
                return super.sendImgCode(os);
            }
        };
        FileOutputStream outputStream = new FileOutputStream(new File("d:/2343.png"));
        String code = imgCodeManager.sendImgCode(outputStream);
        System.out.println(code);*/

        String test="ABC34cccddee";
        System.out.println(test.toUpperCase());//小写转大写

    }


}