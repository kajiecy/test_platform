package org.jsoncloud.framework.verifcode.img;

import org.jsoncloud.framework.verifcode.CodeBean;

/**
 * 图片 验证码
 */
public class ImgCodeBean extends CodeBean {

    public ImgCodeBean(String code, String codeType, String sport) {
        setCode(code);
        setCodeType(codeType);
        setSpot(sport);
    }

    public ImgCodeBean(String code, String codeType) {
        setCode(code);
        setCodeType(codeType);
    }

    public ImgCodeBean(String code) {
        setCode(code);
    }

    public ImgCodeBean() {
        super();
    }
}
