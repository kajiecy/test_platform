package org.jsoncloud.framework.verifcode.sms;

/**
 */
public enum SmsCodeTypeEnum {
    REGISTER("register","注册")
    ,LOGIN("login","登陆")
    ,PHONE_UPDATE("phone_update","修改手机号")
    ,PWD_UPDATE("pwd_update","修改密码")
    ,PWD_FORGET("pwd_forget","忘记密码")
    ,SUB_WITHDRAWALS("phone_change","提现申请")
    ,OTHER("other","其他")
    ;
    private String type;
    private String des;

    SmsCodeTypeEnum(String type, String des) {
        this.type = type;
        this.des = des;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }
}
