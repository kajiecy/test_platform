package org.jsoncloud.framework.verifcode.img;

/**
 */
public enum ImgCodeTypeEnum {
    OTHER("other","其他")
    ;
    private String type;
    private String des;

    ImgCodeTypeEnum(String type, String des) {
        this.type = type;
        this.des = des;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }
}
