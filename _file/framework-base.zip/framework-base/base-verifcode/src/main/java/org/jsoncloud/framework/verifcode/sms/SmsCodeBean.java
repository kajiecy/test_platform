package org.jsoncloud.framework.verifcode.sms;

import org.jsoncloud.framework.verifcode.CodeBean;

import java.util.HashMap;
import java.util.Map;

/**
 * code 验证码
 */
public class SmsCodeBean extends CodeBean {

    private String phone;
    private Map<String,Object> params=new HashMap<String,Object>();

    public SmsCodeBean(String phone, String code, String codeType, String sport) {
        setCodeType(codeType);
        setCode(code);
        setSpot(sport);
        this.phone = phone;
    }

    public SmsCodeBean(String phone, String code, String codeType) {
        setCode(code);
        setCodeType(codeType);
        this.phone = phone;
    }

    public SmsCodeBean(String phone, String code) {
        setCode(code);
        this.phone = phone;
    }

    public SmsCodeBean() {
        super();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Map<String, Object> getParams() {
        return params;
    }

    public void putParam(String key,String value) {
        this.params.put(key,value);
    }

}
