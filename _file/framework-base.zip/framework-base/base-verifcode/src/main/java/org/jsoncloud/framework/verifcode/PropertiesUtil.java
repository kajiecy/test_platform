package org.jsoncloud.framework.verifcode;

import org.jsoncloud.framework.util.StringUtil;

/**
 * Created by Administrator on 2017/3/27.
 */
public class PropertiesUtil extends org.jsoncloud.framework.sms.PropertiesUtil {


    /**************
     * verifcode_img_ 配置
     ****************/
    /**
     * 当前图形验证码有效的时间
     * @return
     */
    public static int verifcodeImgEnableTime() {
        return StringUtil.toInt(get("verifcode_img_enable_time"),10);
    }

    /**************
     * verifcode_sms_ 配置
     ****************/
    /**
     *
     * 当前短信验证码有效的时间
     * @return
     */
    public static int verifcodeSmsEnableTime() {
        return StringUtil.toInt(get("verifcode_sms_enable_time"),10);
    }

    public static String smsAliSignname() {
        return get("sms_ali_signname");
    }

}
