package org.jsoncloud.framework.verifcode.img;

import org.apache.log4j.Logger;
import org.jsoncloud.framework.sms.chuangl.SmsChuangLanUtil;
import org.jsoncloud.framework.util.ImgCodeUtil;
import org.jsoncloud.framework.verifcode.PropertiesUtil;
import org.jsoncloud.framework.verifcode.sms.SmsCodeBean;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Created by Administrator on 2017/3/25.
 */
public abstract class ImgCodeManager {

    protected static Logger logger = Logger.getLogger(ImgCodeManager.class);

    /**
     * 获取短信验证码有效的时间
     *
     * @return 单位 （分钟
     */
    protected static int getEnableTime() {
        return PropertiesUtil.verifcodeImgEnableTime();
    }
    /**
     * 发送验证码
     * @return
     */
    public String sendImgCode(OutputStream os,int w,int h,int codeCount,int lineCount) throws IOException {
        ImgCodeUtil imgCodeUtil = new ImgCodeUtil(w,h,codeCount,lineCount);
        imgCodeUtil.write(os);
        return imgCodeUtil.getCode();
    }
    public String sendImgCode( OutputStream os,int w,int h,int codeCount) throws IOException {
       return sendImgCode(os,w,h,codeCount,150);
    }
    public String sendImgCode(OutputStream os,int w,int h) throws IOException {
        return sendImgCode(os,w,h,5,150);
    }

    public String sendImgCode( OutputStream os) throws IOException {
        return sendImgCode(os,150,50,4,150);
    }

}
