package org.jsoncloud.framework.verifcode;

import java.util.Date;

/**
 * Created by Administrator on 2017/3/27.
 */
public class CodeBean {

    public CodeBean() {
    }

    private String code;
    /**
     * 有效时间 单位分钟
     */
    private int validTime;
    private Date endTime;
    private String codeType;
    /**
     * 出发点，如果是多登陆的时候可以加上，作为验证表示，防止错乱
     */
    private String spot;

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getCodeType() {
        return codeType;
    }

    public void setCodeType(String codeType) {
        this.codeType = codeType;
    }

    public String getSpot() {
        return spot;
    }

    public void setSpot(String spot) {
        this.spot = spot;
    }

    public int getValidTime() {
        return validTime;
    }

    public void setValidTime(int validTime) {
        this.validTime = validTime;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
