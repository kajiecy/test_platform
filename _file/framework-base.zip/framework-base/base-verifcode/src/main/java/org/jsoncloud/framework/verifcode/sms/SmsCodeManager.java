package org.jsoncloud.framework.verifcode.sms;

import org.apache.log4j.Logger;
import org.jsoncloud.framework.sms.ali.SmsAliUtil;
import org.jsoncloud.framework.sms.chuangl.SmsChuangLanUtil;
import org.jsoncloud.framework.util.StringUtil;
import org.jsoncloud.framework.verifcode.PropertiesUtil;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2017/3/25.
 */
public abstract class SmsCodeManager {

    protected static Logger logger = Logger.getLogger(SmsCodeManager.class);

    /**
     * 获取短信验证码有效的时间
     *
     * @return 单位 （分钟
     */
    protected static int getEnableTime() {
        return PropertiesUtil.verifcodeSmsEnableTime();
    }

    /**
     * 发送验证码(创蓝)
     *
     * @param code
     * @param sms_template 模板名 文件common.properties 中匹配
     * @return
     */
    public static boolean sendCodehuangLan(SmsCodeBean code, String sms_template) {
        String temp = PropertiesUtil.get(sms_template);
        if(StringUtil.hasEmpty(temp)){
            logger.error("CHUANGLNA 发送的短信模版["+sms_template+"]没有配置");
            return false;
        }
        String sms = temp.replace("${code}", code.getCode());
        return SmsChuangLanUtil.send(code.getPhone(), sms);
    }

    /**
     * 发送验证码(Ali)
     * 验证码在这里 code.putParam({code:...,});
     * @param code
     * @return
     */
    public static boolean sendCodeAli(SmsCodeBean code,String signName,String template_id) {
        return SmsAliUtil.send(signName,template_id,code.getPhone(),code.getParams());
    }

}
