package org.jsoncloud.framework.sms.chuangl;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Created by Administrator on 2017/4/11.
 */
public class SmsChuangLanUtilTest {
    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void send() throws Exception{
//        SmsChuangLanUtil.send("18656759880","【中华血脉】欢迎体验253云通讯产品验证码是253253");
    }

}