package org.jsoncloud.framework.sms;

import org.jsoncloud.framework.util.StringUtil;

/**
 * Created by Administrator on 2017/3/25.
 */
public class PropertiesUtil extends org.jsoncloud.framework.util.PropertiesUtil {

    /**************
     * sms_ 配置
     ****************/
    /**
     * 默认是不开启 发送短信的调试
     * @return
     */
    public static boolean smsDebug() {
        String sms_debug = StringUtil.toString(get("sms_debug"), "false");
        return !sms_debug.equals("false");
    }

    /**************
     * sms_ali 配置
     ****************/
    public static String smsAliAccessKeyId() {
        return get("sms_ali_access_key_id");
    }

    public static String smsAliAccessKeySecret() {
        return get("sms_ali_access_key_secret");
    }

    /**************
     * sms_chuanglan 配置
     ****************/
    public static String smsChuanglanAccount() {
        return get("sms_chuanglan_account");
    }

    public static String smsChuanglanPassword() {
        return get("sms_chuanglan_password");
    }

    public static String smsChuanglanUrl() {
        return get("sms_chuanglan_url");
    }

}
