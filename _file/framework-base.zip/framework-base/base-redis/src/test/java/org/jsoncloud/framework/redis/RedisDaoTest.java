package org.jsoncloud.framework.redis;

import com.alibaba.fastjson.JSON;
import com.sun.org.apache.regexp.internal.RE;
import org.apache.log4j.Logger;
import org.jsoncloud.framework.util.StringUtil;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.redis.core.BoundHashOperations;
import org.springframework.data.redis.core.BoundListOperations;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by Administrator on 2017/3/24.
 */
@Ignore
public class RedisDaoTest {
    private Logger logger = Logger.getLogger(this.getClass());
    private RedisDao redisDao;
    private ApplicationContext ac = null;

    @Before
    public void start() throws Exception {
        ac = new ClassPathXmlApplicationContext(new String[]{
                "spring/spring-redis.xml"
        });
        redisDao = (RedisDao) ac.getBean("redisDao");
    }

    @Test
    public void setList() throws Exception {
        logger.debug("####list");

    }

    @Test
    public void setListOne() throws Exception {
        logger.debug("####list");



    }

    @Test
    public void getListAll() throws Exception {
        logger.debug("####getListAll");
    }

    @Test
    public void getListOne() throws Exception {
        logger.debug("####getListOne");
    }

    @Test
    public void setHash() throws Exception {
        logger.debug("####setHash");

    }

    @Test
    public void setHashOne() throws Exception {
        logger.debug("####setHashOne");

    }

    @Test
    public void getHashKeys() throws Exception {
        logger.debug("####getHashKeys");
    }

    @Test
    public void getHashOne() throws Exception {
        logger.debug("####getHashOne");
    }

    @Test
    public void hasHashKey() throws Exception {
        logger.debug("####hasHashKey");
    }

    @Test
    public void setValue() throws Exception {
        logger.debug("####setValue");
    }

    @Test
    public void getValue() throws Exception {
        logger.debug("####getValue");
    }

    @Test
    public void deleteKeys() throws Exception {
        logger.debug("####deleteKeys");
    }

    @Test
    public void setKeyExpire() throws Exception {
        logger.debug("####setKeyExpire");
    }

    @Test
    public void setKeyExpire1() throws Exception {
        logger.debug("####setKeyExpire1");
    }

    @Test
    public void setKeyExpire2() throws Exception {
        logger.debug("####setKeyExpire2");
    }

}