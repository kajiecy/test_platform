package org.jsoncloud.framework.redis.token;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.jsoncloud.framework.redis.RedisDao;
import org.jsoncloud.framework.util.StringUtil;

import java.util.Map;

/**
 * redis 中存储 hash集合 关联到用户的登陆对应的 登录名作为唯一键，值信息中包含 唯一token。
 */
public class RedisToken {

    protected RedisDao redisDao;

    public void setRedisDao(RedisDao redisDao) {
        this.redisDao = redisDao;
    }

    /**
     * 当前业务redis 对应的哈希键
     */
    protected String key = "token:haxi";

    public void setKey(String key) {
        this.key = key;
    }

    /**
     * 更具唯一标识，获取最新的数据对象
     *
     * @param token 唯一键
     * @return
     */
    public JSONObject getDataByLogin(String token) {
        String json = redisDao.getHashOne(key, token);
        if (!StringUtil.hasEmpty(json)) {
            JSONObject obj = (JSONObject) JSON.parse(json);
            return obj;
        }
        return null;
    }

    /**
     * 移除存储的数据 登陆用户用的唯一键
     *
     * @param token
     */
    public Long removeDatas(String... token) {
        return redisDao.delHash(key, token);
    }

    /**
     * 执行登陆的操作
     *
     * @param old_token 旧的token 对应的键（删除）
     * @param new_token 新的token （新增）
     * @param data      数据
     * @return
     */
    public void doLogin(String old_token, String new_token, Map<String, Object> data) {
        //根据loginname 获取redis中的数据
        if (!StringUtil.hasEmpty(old_token)
                && redisDao.hasHashKey(key, old_token)) {
            removeDatas(old_token);
        }
        if (StringUtil.hasEmpty(new_token)
                || data == null) {
            return;
        }
        updateData(new_token, data);
    }

    /**
     * 更新登陆的用户的信息
     *
     * @param token 登陆的token
     * @param data  存储的数据对象
     */
    public void updateData(String token, Map<String, Object> data) {
        redisDao.setHashOne(key, token, JSON.toJSONString(data));
    }

}
