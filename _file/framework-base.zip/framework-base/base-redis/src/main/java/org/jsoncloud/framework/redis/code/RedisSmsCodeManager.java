package org.jsoncloud.framework.redis.code;

import com.alibaba.fastjson.JSON;
import org.jsoncloud.framework.redis.RedisDao;
import org.jsoncloud.framework.util.RandUtil;
import org.jsoncloud.framework.util.StringUtil;
import org.jsoncloud.framework.verifcode.sms.SmsCodeBean;
import org.jsoncloud.framework.verifcode.sms.SmsCodeManager;

/**
 * 手机验证码管理
 */
public class RedisSmsCodeManager extends SmsCodeManager {

    private RedisDao redisDao;

    private String keyPre = "smscode:";//redis 键的前缀

    public void setKeyPre(String keyPre) {
        this.keyPre = keyPre;
    }

    public void setRedisDao(RedisDao redisDao) {
        this.redisDao = redisDao;
    }

    /**
     * 构建一个code
     *
     * @param key      redis的键
     * @param phone    验证码的手机号
     * @param codeType 验证码的业务类型
     * @return
     */
    public SmsCodeBean buildSmsCode(String key, String phone, String codeType) {
        //设置有限时间
        Integer smsTime = getEnableTime();
        //获取库中最新的数据,如果存在，就更新有效时间
        SmsCodeBean bean = getSmsCode(key);
        if (bean != null) {
            bean.setPhone(phone);
            bean.setCodeType(codeType);
            bean.setValidTime(smsTime);
            redisDao.setValue(keyPre + key, JSON.toJSONString(bean));
            redisDao.setKeyExpire(keyPre + key, smsTime + 0L);
            return bean;
        }
        SmsCodeBean code = new SmsCodeBean(phone, "" + RandUtil.randomInt(4), codeType);
        code.setValidTime(smsTime);
        redisDao.setValue(keyPre + key, JSON.toJSONString(code));
        redisDao.setKeyExpire(keyPre + key, smsTime + 0L);
        return code;
    }

    /**
     * 获取redis中的验证码
     *
     * @param key redis 的键
     * @return
     */
    public SmsCodeBean getSmsCode(String key) {
        String jsonBean = redisDao.getValue(keyPre + key);
        if (StringUtil.hasEmpty(jsonBean)) {
            return null;
        }
        SmsCodeBean redisCodeBean = JSON.parseObject(jsonBean, SmsCodeBean.class);
        return redisCodeBean;
    }

    /**
     * 校验验证码
     *
     * @return
     */
    public boolean compareCode(String key, String reqcode, String phone, String codeType, String sport) {
        SmsCodeBean bean = getSmsCode(key);
        logger.debug("【SMS验证码对比】:" + JSON.toJSONString(bean));
        if (bean != null
                && bean.getCode().equals(reqcode)
                && (bean.getPhone() == null || bean.getPhone().equals(phone))
                && (bean.getCodeType() == null || bean.getCodeType().equals(codeType))
                && (bean.getSpot() == null || bean.getSpot().equals(sport))
                ) {
            removeSmsCode(key);
            return true;
        }
        return false;
    }

    public boolean compareCode(String key, String reqcode, String phone, String codeType) {
        return compareCode(key, reqcode, phone, codeType, null);
    }

    public boolean compareCode(String key, String reqcode, String phone) {
        return compareCode(key, reqcode, phone, null, null);
    }

    public boolean compareCode(String key, String reqcode) {
        return compareCode(key, reqcode, null, null, null);
    }

    /**
     * 移除redis中的验证码
     *
     * @param key redis 的键
     * @return session中移除掉的验证码sessionCode
     */
    public void removeSmsCode(String key) {
        redisDao.deleteKeys(keyPre + key);
    }

}
