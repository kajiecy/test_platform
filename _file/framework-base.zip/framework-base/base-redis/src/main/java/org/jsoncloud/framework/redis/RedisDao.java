package org.jsoncloud.framework.redis;

import org.jsoncloud.framework.util.StringUtil;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;


public class RedisDao {

    private RedisTemplate redisTemplate;

    public RedisDao() {
    }

    public RedisDao(RedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    public RedisTemplate getRedisTemplate() {
        return redisTemplate;
    }

    public void setRedisTemplate(RedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

//////////////////////////////////////////具体的方法

    /**
     * 重新设置list的值
     *
     * @param key   键
     * @param input 值列表
     * @return 列表长度
     */
    public void setList(String key, List<String> input) {
        if (StringUtil.hasEmpty(key)) {
            return;
        }
        redisTemplate.delete(key);
        if (input != null && input.size() >= 1) {
            redisTemplate.opsForList().rightPushAll(key, input);
        }
    }

    /**
     * 向list中插入一个值
     *
     * @param key   键
     * @param input 值
     */
    public void setListOne(String key, String input) {
        if (StringUtil.hasEmpty(key)) {
            return;
        }
        if (!StringUtil.hasEmpty(input)) {
            redisTemplate.opsForList().rightPush(key, input);
        }
    }

    /**
     * 获得list的所有值
     *
     * @param key 键
     * @return
     */
    public List<String> getListAll(String key) {
        if (StringUtil.hasEmpty(key)) {
            return null;
        }
        return redisTemplate.opsForList().range(key, 0, -1);
    }

    /**
     * 弹出list的一个值
     *
     * @param key 键
     * @return
     */
    public String getListOne(String key) {
        if (StringUtil.hasEmpty(key)) {
            return null;
        }
        return StringUtil.toString(redisTemplate.opsForList().leftPop(key), null);
    }

    /**
     * 重新设置hash值
     *
     * @param key   键
     * @param input 值
     */
    public void setHash(String key, Map<String, String> input) {
        if (StringUtil.hasEmpty(key)) {
            return;
        }
        redisTemplate.delete(key);
        if (input != null && input.size() >= 1) {
            redisTemplate.opsForHash().putAll(key, input);
        }
    }

    /**
     * 设置hash的一个值
     *
     * @param key        键
     * @param inputKey   map键
     * @param inputValue map值
     */
    public void setHashOne(String key, String inputKey, String inputValue) {
        if (StringUtil.hasEmpty(key) || StringUtil.hasEmpty(inputKey)) {
            return;
        }
        redisTemplate.opsForHash().put(key, inputKey, inputValue);
    }

    /**
     * 删除hash 的一个值
     * @param key 键
     * @param objects map键 多个
     * @return
     */
    public Long delHash(String key, Object... objects) {
        if (key == null || objects == null) {
            return 0L;
        }
        return redisTemplate.opsForHash().delete(key, objects);
    }

    /**
     * 获得hash的所有键
     *
     * @param key 键
     * @return 所有键
     */
    public Set<Object> getHashKeys(String key) {
        if (StringUtil.hasEmpty(key)) {
            return null;
        }
        return redisTemplate.opsForHash().keys(key);
    }

    /**
     * 获得hash的指定键
     *
     * @param key      键
     * @param inputKey map键
     */
    public String getHashOne(String key, String inputKey) {
        if (StringUtil.hasEmpty(key) || StringUtil.hasEmpty(inputKey)) {
            return null;
        }
        return (String) redisTemplate.opsForHash().get(key, inputKey);
    }

    /**
     * 检测hash是否含有指定key
     *
     * @param key      键
     * @param inputKey map键
     * @return
     */
    public Boolean hasHashKey(String key, String inputKey) {
        if (StringUtil.hasEmpty(key) || StringUtil.hasEmpty(inputKey)) {
            return null;
        }
        return redisTemplate.opsForHash().hasKey(key, inputKey);
    }


    /**
     * 设置value值
     *
     * @param key
     * @param input
     */
    public void setValue(String key, String input) {
        if (StringUtil.hasEmpty(key)) {
            return;
        }
        if (!StringUtil.hasEmpty(input)) {
            redisTemplate.opsForValue().set(key, input);
        }
    }

    /**
     * 获得value值
     *
     * @param key
     * @return
     */
    public String getValue(String key) {
        if (StringUtil.hasEmpty(key)) {
            return null;
        }
        return StringUtil.toString(redisTemplate.opsForValue().get(key), null);
    }

    /**
     * 删除指定模式的key
     *
     * @param pattern redis模式
     */
    public void deleteKeys(String pattern) {
        if (StringUtil.hasEmpty(pattern)) {
            return;
        }
        Set<String> keys = redisTemplate.keys(pattern);
        if (keys == null || keys.size() <= 0) {
            return;
        }
        redisTemplate.delete(keys);
    }

    /**
     * 设置key超时时间
     *
     * @param key     键
     * @param timeout 超时时间
     * @param unit    时间单位
     */
    public void setKeyExpire(String key, Long timeout, TimeUnit unit) {
        if (StringUtil.hasEmpty(key)) {
            return;
        }
        if (redisTemplate.hasKey(key)) {
            redisTemplate.expire(key, timeout, unit);
        }
    }

    /**
     * 设置key超时分钟
     *
     * @param key     键
     * @param timeout 超时分钟数
     */
    public void setKeyExpire(String key, Long timeout) {
        setKeyExpire(key, timeout, TimeUnit.MINUTES);
    }

    /**
     * 设置失效时间
     *
     * @param key  键
     * @param date 失效时间点
     */
    public void setKeyExpire(String key, Date date) {
        if (StringUtil.hasEmpty(key)) {
            return;
        }
        if (redisTemplate.hasKey(key)) {
            redisTemplate.expireAt(key, date);
        }
    }

}
