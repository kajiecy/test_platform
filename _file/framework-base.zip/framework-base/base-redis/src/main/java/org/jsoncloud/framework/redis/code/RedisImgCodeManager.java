package org.jsoncloud.framework.redis.code;

import com.alibaba.fastjson.JSON;
import org.jsoncloud.framework.redis.RedisDao;
import org.jsoncloud.framework.util.RandUtil;
import org.jsoncloud.framework.util.StringUtil;
import org.jsoncloud.framework.verifcode.img.ImgCodeBean;
import org.jsoncloud.framework.verifcode.img.ImgCodeManager;
import org.jsoncloud.framework.verifcode.sms.SmsCodeBean;
import org.jsoncloud.framework.verifcode.sms.SmsCodeManager;

import java.io.IOException;
import java.io.OutputStream;

/**
 * 手机验证码管理
 */
public class RedisImgCodeManager extends ImgCodeManager {

    private RedisDao redisDao;

    private String keyPre = "imgcode:";//redis 键的前缀

    public void setKeyPre(String keyPre) {
        this.keyPre = keyPre;
    }

    public void setRedisDao(RedisDao redisDao) {
        this.redisDao = redisDao;
    }

    /**
     * 构建一个code
     *
     * @param key      redis的键
     * @param codeType 验证码的业务类型
     * @return
     */
    public ImgCodeBean buildImgCode(String key
            , String codeType, OutputStream os
            , int w, int h, int codeCount
    ) throws IOException {
        //设置有限时间
        Integer smsTime = getEnableTime();
        String imgCode = sendImgCode(os, w, h, codeCount);
        ImgCodeBean code = new ImgCodeBean(imgCode, codeType);
        redisDao.setValue(keyPre + key, JSON.toJSONString(code));
        redisDao.setKeyExpire(keyPre + key, smsTime + 0L);
        return code;
    }

    public ImgCodeBean buildImgCode(String key
            , String codeType, OutputStream os
    ) throws IOException {
        return buildImgCode(key, codeType, os, 150, 50, 4);
    }

    /**
     * 获取redis中的验证码
     *
     * @param key redis 的键
     * @return
     */
    public ImgCodeBean getImgCode(String key) {
        String jsonBean = redisDao.getValue(keyPre + key);
        if (StringUtil.hasEmpty(jsonBean)) {
            return null;
        }
        ImgCodeBean redisCodeBean = JSON.parseObject(jsonBean, ImgCodeBean.class);
        return redisCodeBean;
    }

    /**
     * 校验验证码
     *
     * @param key      redis 的键
     * @param codeType 验证的类型
     * @param reqcode  发送上来的code
     * @return
     */
    public boolean compareCode(String key, String reqcode, String codeType, String sport) {
        if (key == null || reqcode == null) {
            return false;
        }
        ImgCodeBean bean = getImgCode(key);
        if (bean != null
                && bean.getCode().equals(reqcode.toUpperCase())
                && (bean.getCodeType() == null || bean.getCodeType().equals(codeType))
                && (bean.getSpot() == null || bean.getSpot().equals(sport))
                ) {
            removeSmsCode(key);
            return true;
        }
        return false;
    }

    public boolean compareCode(String key, String reqcode, String codeType) {
        return compareCode(key, reqcode, codeType, null);
    }

    public boolean compareCode(String key, String reqcode) {
        return compareCode(key, reqcode, null, null);
    }

    /**
     * 移除redis中的验证码
     *
     * @param key redis 的键
     * @return session中移除掉的验证码sessionCode
     */
    public void removeSmsCode(String key) {
        redisDao.deleteKeys(keyPre + key);
    }

}
