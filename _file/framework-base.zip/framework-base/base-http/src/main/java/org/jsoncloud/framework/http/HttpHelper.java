package org.jsoncloud.framework.http;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.impl.nio.client.HttpAsyncClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.nio.conn.ssl.SSLIOSessionStrategy;
import org.apache.http.ssl.SSLContexts;

import javax.net.ssl.SSLContext;
import java.io.*;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

/**
 * HttpClient 通信助手，可使用同步和异步两种方式发起请求。
 */
public class HttpHelper {

    private final CloseableHttpClient client;
    private final CloseableHttpAsyncClient clientAsync;
    private List<NameValuePair> params;
    private String url;
    private String body;
    private Header[] headers; //头信息
    private HttpResponse response;
    private String encoding = "UTF-8";
    private Map<String, String> paramMap;

    public String getEncoding() {
        return encoding;
    }

    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }

    public HttpHelper(String url) {
        this.url = url;
        this.params = new ArrayList<>();
        client = HttpClients.createDefault();
        clientAsync = HttpAsyncClients.createDefault();
        clientAsync.start();
        paramMap = new HashMap<>();
    }

    /**
     * ssl连接建立
     *
     * @param url
     * @param certFilePath
     * @param sslKey
     * @throws Exception
     */
    @SuppressWarnings("deprecation")
    public HttpHelper(String url, String certFilePath, String sslKey)
            throws Exception {
        this.url = url;
        this.params = new ArrayList<>();
        // 指定读取证书格式为PKCS12
        KeyStore keyStore;
        keyStore = KeyStore.getInstance("PKCS12");
        // 读取本机存放的PKCS12证书文件
        FileInputStream is = null;
        try {
            is = new FileInputStream(new File(certFilePath));
            // 指定PKCS12的密码(商户ID)
            keyStore.load(is, sslKey.toCharArray());
        } finally {
            if (is != null)
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
        SSLContext sslcontext = SSLContexts.custom()
                .loadKeyMaterial(keyStore, sslKey.toCharArray()).build();
        // 指定TLS版本
        SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, new String[]{"TLSv1"}, null, SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER);
        // 设置httpclient的SSLSocketFactory
        client = HttpClients.custom().setSSLSocketFactory(sslsf).build();

        //异步ssl
        SSLIOSessionStrategy sslioSessionStrategy = new SSLIOSessionStrategy(sslcontext, new String[]{"TLSv1"}, null, SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER);
        clientAsync = HttpAsyncClients.custom().setSSLStrategy(sslioSessionStrategy).build();
        clientAsync.start();
    }

    public void setHeaders(Header[] headers) {
        this.headers = headers;
    }

    /**
     * 添加请求参数
     *
     * @param name
     * @param value
     * @return
     */
    public HttpHelper param(String name, Object value) {
        if (value == null)
            return this;
        params.add(new BasicNameValuePair(name, value == null ? null : value
                .toString()));
        paramMap.put(name, value.toString());
        return this;
    }


    /**
     * 读取已经加载的参数:只读方法,对结果map的修改并不影响参数集
     *
     * @return
     */
    public Map<String, String> readParams() {
        Map<String, String> backMap = new HashMap<>();
        backMap.putAll(paramMap);
        return backMap;
    }


    /**
     * 指定发送请求的内容体
     *
     * @param content
     * @return
     */
    public HttpHelper body(String content) {
        this.body = content;
        return this;
    }

    /**
     * 同步GET请求
     *
     * @return
     * @throws IOException
     */
    public HttpHelper get() throws IOException {
        String endpoint = "";
        for (NameValuePair one : params) {
            endpoint += ("&" + one.getName() + "=" + one.getValue());
        }
        if (this.url.lastIndexOf("?") == -1 && endpoint.length() > 0) {
            endpoint = this.url + "?" + endpoint.substring(1);
        } else if (this.url.lastIndexOf("?") != 1) {
            endpoint = this.url + endpoint;
        }
        System.out.println("## get请求url:" + endpoint);
        HttpGet get = new HttpGet(endpoint);
        get.setHeaders(headers);
        this.response = client.execute(get);
        return this;
    }

    /**
     * 异步GET请求
     *
     * @throws IOException
     * @throws ExecutionException
     * @throws InterruptedException
     */
    public void getAsync() throws IOException, ExecutionException, InterruptedException {
        String endpoint = "";
        for (NameValuePair one : params) {
            endpoint += ("&" + one.getName() + "=" + one.getValue());
        }
        if (this.url.lastIndexOf("?") == -1 && endpoint.length() > 0) {
            endpoint = this.url + "?" + endpoint.substring(1);
        } else if (this.url.lastIndexOf("?") != 1) {
            endpoint = this.url + endpoint;
        }
        System.out.println("## get请求url:" + endpoint);
        HttpGet get = new HttpGet(endpoint);
        clientAsync.start();
        clientAsync.execute(get, null);
    }


    /**
     * 同步POST请求
     *
     * @return
     * @throws IOException
     */
    public HttpHelper post() throws IOException {
        HttpPost post = new HttpPost(url);
        post.setHeaders(headers);
        post.setEntity(new UrlEncodedFormEntity(params, this.encoding));
        this.response = client.execute(post);
        return this;
    }

    /**
     * 异步POST请求
     *
     * @throws IOException
     * @throws ExecutionException
     * @throws InterruptedException
     */
    public void postAsync() throws IOException, ExecutionException, InterruptedException {
        HttpPost post = new HttpPost(url);
        post.setHeaders(headers);
        post.setEntity(new UrlEncodedFormEntity(params, this.encoding));
        clientAsync.execute(post, null);
    }

    /**
     * 直接使用内容体发送(同步)
     *
     * @return
     * @throws IOException
     */
    public HttpHelper postBody() throws IOException {
        HttpPost post = new HttpPost(url);
        post.setHeaders(headers);
        post.setEntity(new StringEntity(this.body));
        this.response = client.execute(post);
        return this;
    }


    /**
     * 直接使用内容体发送(异步)
     *
     * @return
     * @throws IOException
     */
    public void postBodyAsync() throws IOException, ExecutionException, InterruptedException {
        HttpPost post = new HttpPost(url);
        post.setHeaders(headers);
        post.setEntity(new StringEntity(this.body));
        clientAsync.execute(post, null);
    }


    /**
     * 同步响应
     *
     * @return
     */
    public String response() {
        if (this.response == null) return null;
        InputStream is = null;
        byte[] result = new byte[1024];
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            is = this.response.getEntity().getContent();
            for (int len = is.read(result); len != -1; len = is.read(result)) {
                bos.write(result, 0, len);
                bos.flush();
            }
        } catch (UnsupportedOperationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (is != null)
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
        try {
            return new String(bos.toByteArray(), this.encoding);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * 关闭连接(同步，异步)
     * 注：除非可以明确地知道请求已经完全结束，否则异步请求调用后请不要使用此方法：
     * 它可能会使主线程在不掌控异步请求线程的情况下，将这个异步请求“关闭”掉，
     * 导致这一异步请求打开后又直接关闭，看起来则好像完全没有发起。
     */
    public void close() {
        if (clientAsync != null) {
            try {
                clientAsync.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (client != null) {
            try {
                client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
