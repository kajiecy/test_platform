package org.jsoncloud.framework.qrcode;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import org.jsoncloud.framework.constant.Constants;
import org.jsoncloud.framework.exception.ErrorEnum;
import org.jsoncloud.framework.exception.ProjectException;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * 二维码生成器
 * Created by Bames on 2016/9/10.
 */
public class QrCodeHelper {
    //二维码输出的图片格式
    public enum Foramt {

        JPG("jpg"), PNG("png");

        Foramt(String name) {
            this.name = name;
        }

        private String name;
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    private static final int BLACK = 0xFF000000;
    private static final int WHITE = 0xFFFFFFFF;

    private final BitMatrix matrix;

    /**
     * 二维码生成器
     *
     * @param contents 生成内容
     * @param edge     正方形边长
     */
    public QrCodeHelper(String contents, int edge) {
        Map hints = new HashMap();
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
        try {
            this.matrix = new MultiFormatWriter().encode(contents, BarcodeFormat.QR_CODE, edge, edge, hints);
        } catch (WriterException e) {
            throw new ProjectException(ErrorEnum.SYSTEM.getCode(), ErrorEnum.SYSTEM.getDescribeCn(), e.getMessage());
        }
    }

    public BufferedImage toBufferedImage() {
        int width = matrix.getWidth();
        int height = matrix.getHeight();
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                image.setRGB(x, y, matrix.get(x, y) ? BLACK : WHITE);
            }
        }
        return image;
    }

    public void toFile(Foramt format, File file) throws IOException {
        BufferedImage image = toBufferedImage();
        if (!ImageIO.write(image, format.getName(), file)) {
            throw new IOException("生成二维码图片失败: format " + format + " to " + file);
        }
    }


    public void toStream(Foramt format, OutputStream stream) throws IOException {
        BufferedImage image = toBufferedImage();
        if (!ImageIO.write(image, format.getName(), stream)) {
            throw new IOException("生成二维码图片失败: format " + format);
        }
    }

}
