package org.jsoncloud.framework.qrcode;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

/**
 * Created by Administrator on 2017/3/16.
 */
public class QrCodeHelperTest {
    Logger logger = Logger.getLogger(this.getClass());

    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
//    @Ignore
    public final void testInsertStringStringString() throws Exception {
        QrCodeHelper helper = new QrCodeHelper("http://www.baidu.com/", 400);

        FileOutputStream fos = new FileOutputStream(new File("E:/baidu.jpg"));
        helper.toStream(QrCodeHelper.Foramt.JPG, fos);
        fos.flush();
        fos.close();

    }

}
