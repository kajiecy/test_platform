package org.jsoncloud.framework.wsdl.soap;

import org.apache.axis.wsdl.WSDL2Java;

/**
 * Created by Administrator on 2017-08-22.
 */
public class SoapConfig {

    public static void main(String[] args) {
    }

}
