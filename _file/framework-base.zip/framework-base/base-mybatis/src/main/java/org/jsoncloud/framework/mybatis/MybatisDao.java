package org.jsoncloud.framework.mybatis;

import org.jsoncloud.framework.bean.Page;
import org.mybatis.spring.SqlSessionTemplate;
import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MybatisDao {

    private SqlSessionTemplate template;

    public MybatisDao() {
        super();
    }

    public MybatisDao(SqlSessionTemplate template) {
        this.template = template;
    }

    public void setTemplate(SqlSessionTemplate template) {
        this.template = template;
    }

    public SqlSessionTemplate getTemplate() {
        return template;
    }

    public <T> List<T> selectList(Class<T> cls, String statement, Object condition) {
        return template.selectList(statement, condition);
    }

    public List<Map<String, Object>> selectMapList(String statement, Object condition) {
        return template.selectList(statement, condition);
    }

    public <T> T selectOne(Class<T> cls, String statement, Object condition) {
        return template.selectOne(statement, condition);
    }

    public Map<String, Object> selectMapOne(String statement, Object condition) {
        return template.selectOne(statement, condition);
    }

    public <K, V> Map<K, V> selectMap(Class<V> cls, String statement, Object condition, String mapKey) {
        return template.selectMap(statement, condition, mapKey);
    }

    public void selectPage(Page page, String selectPage, String selectCount) {
        int limit = page.getLimit();
        int start = page.getStart();
        Map<String, Object> condition = new HashMap<String, Object>();
        condition.putAll(page.getCondition());
        int counts = template.selectOne(selectCount, condition);
        page.setTotal(counts);
        condition.put("offset", start);
        condition.put("limit", limit);
        List<Map<String, Object>> mapList = template.selectList(selectPage, condition);
        page.setResults(mapList);
    }

    /**
     * 插入对象
     *
     * @param insertName
     * @param condition
     * @return
     */
    public int insert(String insertName, Object condition) {
        return this.template.insert(insertName, condition);
    }

    /**
     * 更新对象
     *
     * @param updateName
     * @param condition
     * @return
     */
    public int update(String updateName, Object condition) {
        return this.template.update(updateName, condition);
    }

    public int delete(String statement, Object condition) {
        return this.template.delete(statement, condition);
    }

}
