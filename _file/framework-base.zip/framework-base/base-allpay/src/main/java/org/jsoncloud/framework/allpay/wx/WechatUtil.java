package org.jsoncloud.framework.allpay.wx;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.http.HttpRequest;
import org.apache.log4j.Logger;
import org.jsoncloud.framework.allpay.PropertiesUtil;
import org.jsoncloud.framework.allpay.wx.entity.Commodity;
import org.jsoncloud.framework.allpay.wx.entity.PayOrder;
import org.jsoncloud.framework.allpay.wx.entity.WxPay;
import org.jsoncloud.framework.allpay.wx.exception.ConnectNonOpenException;
import org.jsoncloud.framework.allpay.wx.untifycall.WechatUnifyService;
import org.jsoncloud.framework.allpay.wx.util.SignUtil;
import org.jsoncloud.framework.allpay.wx.util.StringUtil;
import org.jsoncloud.framework.allpay.wx.util.XmlParseUtil;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

/**
 * 微信帮助类
 */
public class WechatUtil {

    public static Logger logger = Logger.getLogger(WechatUtil.class);

    public static Map<String, Object> getAppPayInfo(
            String orderNo
            , String orderName
            , int finalMoney
            , String notifurl
    ) throws Exception {
        return getAppPayInfo(orderNo, orderName, finalMoney, notifurl, "");
    }

    /**
     * 获取APP支付需要的相关信息
     *
     * @return map:{
     * <p>
     * nonce_str=HhFcQJI8dxJ06VSC
     * , appid=wx492342f3b67d82f9
     * , sign=01F40C5DFEBFEA33510D43FFBD1339D2
     * , trade_type=APP
     * , return_msg=OK
     * , result_code=SUCCESS
     * , mch_id=1292465201
     * , return_code=SUCCESS
     * , prepay_id=wx2015122415550962db83977f0970105561
     * <p>
     * }
     */
    public static Map<String, Object> getAppPayInfo(
            String orderNo
            , String orderName
            , int final_money
            , String notifurl
            , String order_id
    ) throws Exception {
        //商户及用户信息
        String appid = PropertiesUtil.getWechatAppId();
        String mchid = PropertiesUtil.getWechatAppMchid();
        String paykey = PropertiesUtil.getWechatApiPaykey();

        if (PropertiesUtil.getPayDebug()) {
            final_money = 1;
        } else if (final_money <= 0) {
            throw new Exception("支付金额必须大于0");
        }

        //定义商品
        Commodity commodity = new Commodity(orderName, null, orderNo, order_id);

        //定义支付清单 final_money
        PayOrder order = new PayOrder(final_money, "APP", null, null, orderNo);
        //获得支付预请求服务
        WxPay wxpay = new WxPay(null, appid, mchid, paykey, null, notifurl, order, commodity);
        String result = null;
        result = WechatUnifyService.pay(wxpay);

        logger.debug("支付预请求服务-解析前:\n" + result);
        Map<String, String> resultmap = XmlParseUtil.getMap(result);
        logger.debug("支付预请求服务-解析后:\n" + JSON.toJSONString(resultmap));
        if (resultmap.get("return_code").equals("FAIL")
                || resultmap.get("result_code").equals("FAIL")) { //如果为success表示通信标识已经连接成功,如果fail则说明通信失败,跳转提示部成功
            throw new ConnectNonOpenException("获取【prepay_id】失败", null);
        }

        /*
           resultmap： {
            nonce_str=HhFcQJI8dxJ06VSC
            , appid=wx492342f3b67d82f9
            , sign=01F40C5DFEBFEA33510D43FFBD1339D2
            , trade_type=APP
            , return_msg=OK
            , result_code=SUCCESS
            , mch_id=1292465201
            , return_code=SUCCESS
            , prepay_id=wx2015122415550962db83977f0970105561
            }
        */
        /*
            生成app端，支付需要的参数｛
                appid，partnerid，prepayid，noncestr，package，timestamp，sign
            ｝
            根据api文档，package= Sign=WXPay
                noncestr =
                timestamp =
                sign 重新签名
        */
        Map<String, Object> appPayParams = new HashMap<String, Object>();
        appPayParams.put("appid", appid);
        appPayParams.put("partnerid", mchid);
        appPayParams.put("prepayid", resultmap.get("prepay_id"));
        appPayParams.put("noncestr", StringUtil.getRandomString(32));
        appPayParams.put("package", "Sign=WXPay");
        appPayParams.put("timestamp", (System.currentTimeMillis() + "").substring(0, 10));
        appPayParams.put("sign", getSign(appPayParams));

        return appPayParams;
    }

    /**
     * 校验微信的支付
     * 如果ok，返回对应的参数信息，否则返回其他信息
     {
     "is_subscribe":"N"
     ,"appid":"wx920a6ae63ab680d9"
     ,"fee_type":"CNY"
     ,"nonce_str":"5uyQGMx3qGq6vMdR3Lx4lX99dwFfTskP"
     ,"out_trade_no":"1704252131340274970378"
     ,"transaction_id":"4000092001201704258344296071"
     ,"trade_type":"APP"
     ,"sign":"ACA75E374DA04EEE58A450B5ABEB18C5"
     ,"result_code":"SUCCESS"
     ,"mch_id":"1315639801"
     ,"total_fee":"1"
     ,"attach":"1704252131340274970378_31"
     ,"time_end":"20170425213155"
     ,"openid":"ocb2GxALhKfPuuGJKpM4GKFcWlvc"
     ,"bank_type":"CFT"
     ,"return_code":"SUCCESS"
     ,"cash_fee":"1"
     }
     * @param request
     * @return
     * @throws Exception
     */
    public static Map<String, String> checkWechat(HttpServletRequest request) throws Exception {
        Map<String, String> feedback = new HashMap<String, String>();
        feedback.put("return_code", "FAIL");

        String bodyXml = _readResponseBody(request);
        logger.info("## 微信通知 [payType],支付结果:" + bodyXml);
        Map<String, String> wechatParams = WechatCore.parseMapFrom(bodyXml);

        String valid = WechatCore.sign(wechatParams, PropertiesUtil.getWechatApiPaykey());
        String sign = wechatParams.get("sign");
        logger.info("## 微信订单支付,验证签名:" + valid + ",微信反馈:" + bodyXml);
        logger.warn("## 微信订单支付,微信 sign[" + sign + "]");
        if (!sign.equals(valid)) {
            return null;
        }
        logger.debug("微信回调验证成功-<返回参数>：<" + JSON.toJSONString(wechatParams) + ">");
        return wechatParams;
    }

    /**
     * 读取request中的请求体
     */
    private static String _readResponseBody(HttpServletRequest request)
            throws Exception {
        BufferedReader input = null;
        StringBuffer sb = new StringBuffer();
        try {
            input = new BufferedReader(new InputStreamReader(
                    request.getInputStream()));
            for (String line = input.readLine(); line != null; line = input
                    .readLine()) {
                sb.append(line);
            }
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            throw new Exception("ERROR_读取请求体失败");
        } finally {
            if (input != null)
                try {
                    input.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
        return sb.toString();
    }

    private static String getSign(Map<String, Object> map) {
        List<String> list = new ArrayList<String>(map.keySet());
        Collections.sort(list, new Comparator<String>() {
            //升序排序
            public int compare(String o1,
                               String o2) {
                return o1.compareTo(o2);
            }
        });
        StringBuffer sb1 = new StringBuffer();
        for (String str : list) {
            Object o = map.get(str);
            if (o != null && !o.toString().trim().equals(""))
                sb1.append(str + "=" + o.toString() + "&");
        }
        String stringA = sb1.toString().substring(0, sb1.length() - 1);//生成StringA
        //拼接API秘钥
        String stringSignTemp = stringA + "&key=" + PropertiesUtil.getWechatApiPaykey();
        //md5加密,转大写
        //System.out.println(stringSignTemp);
        return SignUtil.md5(stringSignTemp).toUpperCase();
    }

}
