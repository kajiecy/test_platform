package org.jsoncloud.framework.allpay.wx.autoserver;

/**
 * 接收微信事件处理接口
 * @author sundhu
 *
 */
public interface IWechatEvent {
	
	/**
	 * 关注
	 * @param body
	 */
	public void subscribe(MsgBody body);
	
	/**
	 * 取消关注
	 * @param body
	 */
	public void unSubscribe(MsgBody body);
	
}
