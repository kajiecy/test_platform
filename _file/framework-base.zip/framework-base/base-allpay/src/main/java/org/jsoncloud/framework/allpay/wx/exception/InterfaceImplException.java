package org.jsoncloud.framework.allpay.wx.exception;

/**
 *接口实现异常
 * @author Administrator
 *
 */
public class InterfaceImplException extends RuntimeException{
	public InterfaceImplException(String mess){
		super(mess);
	}
}
