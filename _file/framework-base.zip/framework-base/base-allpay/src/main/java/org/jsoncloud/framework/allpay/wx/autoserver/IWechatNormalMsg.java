package org.jsoncloud.framework.allpay.wx.autoserver;

/**
 * 接收普通消息接口
 * @author sundhu
 *
 */
public interface IWechatNormalMsg {

}
