package org.jsoncloud.framework.allpay.alipay;

import com.alibaba.fastjson.JSONObject;
import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.domain.AlipayTradeAppPayModel;
import com.alipay.api.internal.util.AlipaySignature;
import com.alipay.api.request.AlipayTradeAppPayRequest;
import com.alipay.api.request.AlipayTradeRefundRequest;
import com.alipay.api.response.AlipayTradeAppPayResponse;
import com.alipay.api.response.AlipayTradeRefundResponse;
import org.apache.log4j.Logger;
import org.jsoncloud.framework.allpay.PropertiesUtil;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

public class AlipayUtil {
    private static Logger logger = Logger.getLogger(AlipayUtil.class);

    public static String sendFail() {
        return "fail";
    }

    public static String sendSuccess() {
        return "success";
    }


    /**
     * 获取支付的字符串
     *
     * @param body
     * @param subject
     * @param total
     * @param outtradeno
     * @param notifyUrl
     * @return
     */
    public static AlipayTradeAppPayResponse
    getAppPayStr(String body, String subject, String total, String outtradeno
            , String notifyUrl) {
        //实例化客户端
        AlipayClient alipayClient = new DefaultAlipayClient(
                PropertiesUtil.getAlipayServerUrl()
                , PropertiesUtil.getAlipayAppId()
                , PropertiesUtil.getAlipayPrivateKey()
                , "json"
                , PropertiesUtil.getAlipayCharset()
                , PropertiesUtil.getAlipayPublicKey()
                , PropertiesUtil.getAlipaySignType());
        //实例化具体API对应的request类,类名称和接口名称对应,当前调用接口名称：alipay.trade.app.pay
        AlipayTradeAppPayRequest request = new AlipayTradeAppPayRequest();
        //SDK已经封装掉了公共参数，这里只需要传入业务参数。以下方法为sdk的model入参方式(model和biz_content同时存在的情况下取biz_content)。
        AlipayTradeAppPayModel model = new AlipayTradeAppPayModel();
        model.setBody(body);
        model.setSubject(subject);
        model.setOutTradeNo(outtradeno);
        model.setTimeoutExpress("10m");
        if (PropertiesUtil.getPayDebug()) {
            model.setTotalAmount("0.01");
        } else {
            model.setTotalAmount(total);
        }
        model.setProductCode("QUICK_MSECURITY_PAY");
        request.setBizModel(model);
        request.setNotifyUrl(notifyUrl);
        try {
            //这里和普通的接口调用不同，使用的是sdkExecute
            AlipayTradeAppPayResponse response = alipayClient.sdkExecute(request);
//            System.out.println(response.getBody());//就是orderString 可以直接给客户端请求，无需再做处理。
            return response;
        } catch (AlipayApiException e) {
            logger.error("", e);
        }
        return null;
    }

    /**
     * 验证是否是支付回调
     *
     * @param request
     * @return
     */
    public static boolean checkAlipaySignature(HttpServletRequest request) {
        //获取支付宝POST过来反馈信息
        Map<String, String> params = new HashMap<String, String>();
        Map requestParams = request.getParameterMap();
        for (Iterator iter = requestParams.keySet().iterator(); iter.hasNext(); ) {
            String name = (String) iter.next();
            String[] values = (String[]) requestParams.get(name);
            String valueStr = "";
            for (int i = 0; i < values.length; i++) {
                valueStr = (i == values.length - 1) ? valueStr + values[i]
                        : valueStr + values[i] + ",";
            }
            //乱码解决，这段代码在出现乱码时使用。
//            valueStr = new String(valueStr.getBytes("ISO-8859-1"), "utf-8");

            params.put(name, valueStr);
        }
        logger.info("## ========= <<PAY>> ========>> 支付宝回调通知，验证支付宝参数：params:" + params);
        //切记alipaypublickey是支付宝的公钥，请去open.alipay.com对应应用下查看。
        //boolean AlipaySignature.rsaCheckV1(Map<String, String> params, String publicKey, String charset, String sign_type)
        try {
            boolean flag = AlipaySignature.rsaCheckV1(params, PropertiesUtil.getAlipayPublicKey()
                    , PropertiesUtil.getAlipayCharset()
                    , PropertiesUtil.getAlipaySignType());
            return flag;
        } catch (AlipayApiException e) {
            logger.error("", e);
            return false;
        }
    }

    /**
     * @param trade_no      支付宝交易号，和商户订单号不能同时为空
     * @param refund_amount 需要退款的金额，该金额不能大于订单金额,单位为元，支持两位小数
     */
    public static AlipayTradeRefundResponse alipayRefundRequest(
            String trade_no
            , double refund_amount
    ) throws AlipayApiException {
        return alipayRefundRequest(null, trade_no, refund_amount, null, null);
    }

    /**
     * @param out_trade_no  订单支付时传入的商户订单号,不能和 trade_no同时为空。
     * @param trade_no      支付宝交易号，和商户订单号不能同时为空
     * @param refund_amount 需要退款的金额，该金额不能大于订单金额,单位为元，支持两位小数
     */
    public static AlipayTradeRefundResponse alipayRefundRequest(
            String out_trade_no
            , String trade_no
            , double refund_amount
    ) throws AlipayApiException {
        return alipayRefundRequest(out_trade_no, trade_no, refund_amount, null, null);
    }

    /**
     * @param out_trade_no  订单支付时传入的商户订单号,不能和 trade_no同时为空。
     * @param trade_no      支付宝交易号，和商户订单号不能同时为空
     * @param refund_amount 需要退款的金额，该金额不能大于订单金额,单位为元，支持两位小数
     * @param refund_reason 退款的原因说明 可选
     */
    public static AlipayTradeRefundResponse alipayRefundRequest(
            String out_trade_no
            , String trade_no
            , double refund_amount
            , String refund_reason
    ) throws AlipayApiException {
        return alipayRefundRequest(out_trade_no, trade_no, refund_amount, refund_reason, null);
    }

    /**
     * @param out_trade_no   订单支付时传入的商户订单号,不能和 trade_no同时为空。
     * @param trade_no       支付宝交易号，和商户订单号不能同时为空
     * @param refund_amount  需要退款的金额，该金额不能大于订单金额,单位为元，支持两位小数
     * @param refund_reason  退款的原因说明 可选
     * @param out_request_no 64 标识一次退款请求，同一笔交易多次退款需要保证唯一，如需部分退款，则此参数必传。
     *                       参考：https://doc.open.alipay.com/docs/api.htm?spm=a219a.7386797.0.0.hLs92O&docType=4&apiId=759
     */
    public static AlipayTradeRefundResponse alipayRefundRequest(
            String out_trade_no
            , String trade_no
            , double refund_amount
            , String refund_reason
            , String out_request_no
    ) throws AlipayApiException {
        // 发送请求
        AlipayClient alipayClient = new DefaultAlipayClient
                (PropertiesUtil.getAlipayServerUrl()
                        , PropertiesUtil.getAlipayAppId(),
                        PropertiesUtil.getAlipayPrivateKey()
                        , "json"
                        , PropertiesUtil.getAlipayCharset()
                        , PropertiesUtil.getAlipayPublicKey()
                        , PropertiesUtil.getAlipaySignType());
        AlipayTradeRefundRequest request = new AlipayTradeRefundRequest();
        JSONObject object = new JSONObject();
        object.put("out_trade_no", out_trade_no);
        object.put("trade_no", trade_no);
        object.put("refund_amount", refund_amount);
        if (refund_reason != null) {
            object.put("refund_reason", refund_reason);
        }
        if (out_request_no != null) {
            object.put("out_request_no", out_request_no);
        }
        request.setBizContent(object.toJSONString());
        return alipayClient.execute(request);
    }

    /**
     * 判断是否支付成功
     * @param response
     * @return
     */
    public static boolean hasTradeRefundSuccess(AlipayTradeRefundResponse response) {
        if ("10000".equals(response.getCode())) {
            return true;
        }
        return false;
    }

    /**
     * 获取到支付失败的原因
     * @param response
     * @return
     */
    public static String tradeRefundFaildMsg(AlipayTradeRefundResponse response) {
        return response.getSubMsg();
    }

}
