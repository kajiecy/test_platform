package org.jsoncloud.framework.allpay.wx.sessionserver;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONException;

/**
 * 微信公众号 基础支持接口
 * @author sundhu
 */
public interface IBaseSupportServer {
	/**
	 * 官方介绍：access_token是公众号的全局唯一票据，公众号调用各接口时都需使用access_token，access_token有一个失效时间，在失效时间内需重新获取。<br>
	 * 推荐实现思路：由第三方中控服务（进程、线程）管理access_token，该方法获取第三方中控的提供的值即可。<br>
	 * @return String
	 */
	public String getAccessToken(); 
	
	/**
	 * 官方介绍：如果公众号基于安全等考虑，需要获知微信服务器的IP地址列表，以便进行相关限制，可以通过该接口获得微信服务器IP地址列表。<br>
	 * @return
	 * ["127.0.0.1","127.0.0.1"]
	 */
	public List<String> getWxServerIp(String accessToken);
	
	/**
	 * 根据用户openid和accesstoken获取用户用户信息
	 * @param openid
	 * @return
	 */
	public Map<String,Object> getWXUserInfoByOpenid(String accesstoken, String openid) throws IOException,JSONException;
	
	/**
	 * 根据网页授权 获取用户微信信息
	 * @param accessToken
	 * @param openid
	 * @return
	 * @throws IOException
	 * @throws JSONException
	 */
	public Map<String,Object> getGrantWxInfo(String accessToken, String openid) throws IOException,JSONException;
	
	/**
	 * 向微信用户的客户端推送消息
	 * @param message
	 * @param accesstoken
	 * @param openid
	 * @return
	 * @throws IOException
	 * @throws JSONException
	 */
	public Map<String,Object> sendInfoToWxClient(String message, String accesstoken, String openid) throws IOException,JSONException;
}
