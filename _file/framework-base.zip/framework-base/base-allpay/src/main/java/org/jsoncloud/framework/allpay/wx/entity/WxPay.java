package org.jsoncloud.framework.allpay.wx.entity;

import org.jsoncloud.framework.allpay.wx.util.SignUtil;
import org.jsoncloud.framework.allpay.wx.util.StringUtil;

import java.util.*;

/**
 * 微信支付
 * @author Administrator
 *
 */
public class WxPay {
	private String appid;
	private String mchId;
	private String deviceInfo;
	private String nonceStr;
	private String sign;
	private String paykey;
	private String userDbId;
	private TreeMap<String, Object> map=new TreeMap<String,Object>();
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

	/**
	 * 通知回调地址 非空
	 */
	private String notifyUrl;
	private PayOrder payList;
	private Commodity commodity;

	public WxPay(String userDbId,String appid,String mchId,String paykey,String deviceInfo,String notifyUrl,PayOrder paylist,Commodity commodity){
		this.userDbId=userDbId;
		this.appid=appid;
		this.mchId=mchId;
		this.notifyUrl=notifyUrl;
		this.deviceInfo=deviceInfo;
		this.paykey=paykey;
		if(paylist.getTradeType().equals("NATIVE")){
			if(commodity.getProductId()==null)throw new IllegalArgumentException("当tradeType为NATIVE时，商品ID（productId）不能为空");
		}
		this.payList=paylist;
		this.commodity=commodity;
		
	}
	
	private String getNonceStr(){
		return StringUtil.getRandomString(32);
	}

	public String getResultForPay(){
		this.nonceStr=this.getNonceStr();
		this.setMap();
		this.sign=this.getSign();
		StringBuilder sb=new StringBuilder();
		this.map.put("sign", this.sign);
		Set<String> keys = this.map.keySet();
		Iterator<String> it = keys.iterator();
		sb.append("<xml>");
		while(it.hasNext()){
			String key = it.next();
			Object value = this.map.get(key);
			if(value==null)continue;
			String cddata="<![CDATA["+value+"]]>";
			if(value instanceof Number){
				cddata=value.toString();
			}
			sb.append("<"+key+">"+cddata+"</"+key+">");
		}
		sb.append("</xml>");
		return sb.toString().trim();
	}
	
	public void setMap(){
		map.put("appid", this.appid);
		map.put("mch_id", this.mchId);
		map.put("device_info", this.deviceInfo);
		map.put("nonce_str", this.nonceStr);
		map.put("body", this.commodity.getBody());
		map.put("detail",this.commodity.getDetail());
		map.put("attach", this.commodity.getAttach());
		map.put("out_trade_no", this.payList.getOutTradeNo());
		map.put("fee_type", this.payList.getFeeType());
		map.put("total_fee", this.payList.getTotalFee());
		map.put("spbill_create_ip", this.payList.getSpbillCreateIp());
		map.put("time_start", this.payList.getStartTime());
		map.put("time_expire", this.payList.getEndTime());
		map.put("goods_tag", this.commodity.getGoodsTag());
		map.put("notify_url", this.notifyUrl);
		map.put("trade_type", this.payList.getTradeType());
		map.put("product_id", this.commodity.getProductId());
		map.put("openid", this.payList.getOpenId());
	}

	private String getSign(){
		List<String> list=new ArrayList<String>(map.keySet());
		Collections.sort(list,new Comparator<String>() {
            //升序排序
            public int compare(String o1,
            		String o2) {
                return o1.compareTo(o2);
            }
        });
		StringBuffer sb1=new StringBuffer();
		for (String str : list) {
			Object o = map.get(str);
			if(o!=null&&!o.toString().trim().equals(""))
			sb1.append(str+"="+o.toString()+"&");
		}
		String stringA = sb1.toString().substring(0,sb1.length()-1);//生成StringA
		//拼接API秘钥
		String stringSignTemp=stringA+"&key="+paykey;
		//md5加密,转大写
		//System.out.println(stringSignTemp);
		return SignUtil.md5(stringSignTemp).toUpperCase();
	}

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public String getMchId() {
		return mchId;
	}

	public void setMchId(String mchId) {
		this.mchId = mchId;
	}

	public String getDeviceInfo() {
		return deviceInfo;
	}

	public void setDeviceInfo(String deviceInfo) {
		this.deviceInfo = deviceInfo;
	}

	public String getPaykey() {
		return paykey;
	}

	public void setPaykey(String paykey) {
		this.paykey = paykey;
	}

	public String getUserDbId() {
		return userDbId;
	}

	public void setUserDbId(String userDbId) {
		this.userDbId = userDbId;
	}

	public TreeMap<String, Object> getMap() {
		return map;
	}

	public void setMap(TreeMap<String, Object> map) {
		this.map = map;
	}

	public String getNotifyUrl() {
		return notifyUrl;
	}

	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}

	public PayOrder getPayList() {
		return payList;
	}

	public void setPayList(PayOrder payList) {
		this.payList = payList;
	}

	public Commodity getCommodity() {
		return commodity;
	}

	public void setCommodity(Commodity commodity) {
		this.commodity = commodity;
	}

	public void setNonceStr(String nonceStr) {
		this.nonceStr = nonceStr;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}
	
	
	
}
