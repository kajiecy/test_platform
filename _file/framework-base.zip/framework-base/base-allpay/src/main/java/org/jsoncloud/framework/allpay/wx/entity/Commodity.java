package org.jsoncloud.framework.allpay.wx.entity;

/**
 * 商品类
 * @author Administrator
 *
 */
public class Commodity {
	
	/**
	 * 商品描述,非空
	 */
	private String body;
	
	/**
	 * 商品详情
	 */
	private String detail;
	
	/**
	 * 附加数据，在查询API和支付通知中原样返回，该字段主要用于商户携带订单的自定义数据
	 * 例：同时有几个应用使用该商户支付账号，则用于区分不同应用
	 */
	private String attach;
	
	/**
	 * 商品标记
	 * 商品标记，代金券或立减优惠功能的参数，说明详见代金券或立减优惠
	 */
	private String goodsTag;
	
	/**
	 * trade_type=NATIVE，此参数必传。此id为二维码中包含的商品ID，商户自行定义。
	 */
	private String productId;

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		if(body==null)throw new IllegalArgumentException("传入的参数不能为空");
		this.body = body;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public String getAttach() {
		return attach;
	}

	public void setAttach(String attach) {
		this.attach = attach;
	}

	public String getGoodsTag() {
		return goodsTag;
	}

	public void setGoodsTag(String goodsTag) {
		this.goodsTag = goodsTag;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * 
	 * @param body 商品描述,非空
	 * @param detail 商品详情 
	 * @param attach 附加数据，在查询API和支付通知中原样返回，该字段主要用于商户携带订单的自定义数据
	 * @param goodsTag 商品标记，代金券或立减优惠功能的参数，说明详见代金券或立减优惠
	 * @param productId trade_type=NATIVE，此参数必传。此id为二维码中包含的商品ID，商户自行定义。
	 */
	public Commodity(String body, String detail, String attach,
			String goodsTag, String productId) {
		super();
		if(body==null||body.trim().equals(""))throw new IllegalArgumentException("传入的body参数不能为空");
		if(productId==null||productId.trim().equals(""))throw new IllegalArgumentException("传入的productId参数不能为空");
		if(attach==null||attach.trim().equals(""))throw new IllegalArgumentException("传入的attachDesc参数不能为空");
		this.body = body;
		this.detail=detail;
		this.attach=attach;
		this.goodsTag=goodsTag;
		this.productId=productId;
	}
	
	public Commodity(String body, String detail, String attach,String productId) {
		super();
		if(body==null||body.trim().equals(""))throw new IllegalArgumentException("传入的body参数不能为空");
		if(productId==null||productId.trim().equals(""))throw new IllegalArgumentException("传入的productId参数不能为空");
		if(attach==null||attach.trim().equals(""))throw new IllegalArgumentException("传入的attachDesc参数不能为空");
		this.body = body;
		this.detail=detail;
		this.productId=productId;
		this.attach=attach+"_"+this.productId;

	}

}
