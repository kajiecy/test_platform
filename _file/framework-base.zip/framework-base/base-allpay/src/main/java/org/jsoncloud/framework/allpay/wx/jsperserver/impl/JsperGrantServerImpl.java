package org.jsoncloud.framework.allpay.wx.jsperserver.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;

import org.apache.log4j.Logger;
import org.jsoncloud.framework.allpay.wx.exception.ConnectNonOpenException;
import org.jsoncloud.framework.allpay.wx.jsperserver.IJsperGrantServer;
import org.jsoncloud.framework.allpay.wx.util.*;

public class JsperGrantServerImpl implements IJsperGrantServer {

    private static Logger logger = Logger.getLogger(JsperGrantServerImpl.class);

    private JsperGrantServerImpl() {
    }

    private static JsperGrantServerImpl instance = null;

    public static JsperGrantServerImpl getInstance() {
        if (instance == null) instance = new JsperGrantServerImpl();
        return instance;
    }


    public String getJsApiTicket() {
        try {
            return GetterFactory.getter().getJsApiTicket();
        } catch (ConnectNonOpenException e) {
            logger.error(e);
            return null;
        }
    }


    public Map<String, Object> getJsperWxConfig(String jsApiTicket,
                                                String appId, String url) {
        Map<String, Object> map = new HashMap<String, Object>();
        long timestamp = StringUtil.getTimestampBySs();
        String noncestr = StringUtil.getRandomString(16);
        //wxconfig签名 timestamp S小写
        String qianming = "jsapi_ticket=" + jsApiTicket + "&noncestr=" + noncestr + "&timestamp=" + timestamp + "&url=" + url;

        logger.debug("qianming:" + qianming);

        String signature = SignUtil.SHA1(qianming.trim());
        map.put("noncestr", noncestr);
        map.put("signature", signature);
        map.put("timestamp", timestamp);
        map.put("appId", appId);
        logger.debug("wxconfig_map:" + map);
        return map;
    }

    public Map<String, Object> getJsperWxPayParam(String appId, String paykey, String packagestr) {
        //参与签名的字段 appId, timeStamp, nonceStr, package, signType
        TreeMap<String, Object> map = new TreeMap<String, Object>();
        map.put("appId", appId);
        map.put("timeStamp", StringUtil.getTimestampBySs());
        map.put("nonceStr", StringUtil.getRandomString(16));
        map.put("package", packagestr);
        map.put("signType", "MD5");
        List<String> list = new ArrayList<String>(map.keySet());
        Collections.sort(list, new Comparator<String>() {
            //升序排序
            public int compare(String o1,
                               String o2) {
                return o1.compareTo(o2);
            }
        });
        StringBuffer sb = new StringBuffer();
        for (String str : list) {
            sb.append(str + "=" + map.get(str) + "&");
        }
        String signstr = sb.toString() + "key=" + paykey;
        System.out.print("jsperGrantServerImpl.getJsperWxPayParam -->str:" + signstr);
        map.put("paySign", SignUtil.md5(signstr).toUpperCase());
        return map;
    }


    private String getOpenIdUrl = "https://api.weixin.qq.com/sns/oauth2/access_token?";
    private HttpRequestUtil request = new HttpRequestUtil();

    public Map<String, Object> getAccessTokenAndOpenIdByCode(String appId,
                                                             String secret, String code) throws IOException, JSONException {
        String param = "appid=" + appId + "&secret=" + secret + "&code=" + code + "&grant_type=authorization_code";
        String str = request.httpResultHasHeader(getOpenIdUrl + param, null);
        //{ "access_token":"ACCESS_TOKEN", "expires_in":7200,
        //	"refresh_token":"REFRESH_TOKEN", "openid":"OPENID",
        //	"scope":"SCOPE", "unionid": "o6_bmasdasdsad6_2sgVt7hMZOPfL" }
        return JsonUtil.getMapByJson(JSON.parseObject(str));
    }


    /**
     * {
     * "access_token":"ACCESS_TOKEN",
     * "expires_in":7200,
     * "refresh_token":"REFRESH_TOKEN",
     * "openid":"OPENID",
     * "scope":"SCOPE"
     * }
     */
    public Map<String, Object> getRefreshAccessTokenByOAuth(String appId, String refreshToken) throws IOException, JSONException {
        String httpurl = "https://api.weixin.qq.com/sns/oauth2/refresh_token?appid=" + appId + "&grant_type=refresh_token&refresh_token=" + refreshToken;
        String str = request.httpResultHasHeader(httpurl, null);
        return JsonUtil.getMapByJson(JSON.parseObject(str));
    }

}
