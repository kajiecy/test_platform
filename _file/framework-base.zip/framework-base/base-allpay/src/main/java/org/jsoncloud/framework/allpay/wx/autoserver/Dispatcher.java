package org.jsoncloud.framework.allpay.wx.autoserver;


public class Dispatcher {
	
	private IWechatNormalMsg iWechatNormalMsg;
	private IWechatEvent iWerchatEvent;
	
	
	
	public Dispatcher(IWechatNormalMsg iWechatNormalMsg,
			IWechatEvent iWerchatEvent) {
		super();
		this.iWechatNormalMsg = iWechatNormalMsg;
		this.iWerchatEvent = iWerchatEvent;
	}


	public void process(MsgBody body){
		MsgType type = body.getMsgType();
		switch (type) {
			//当关注事件产生时候
			case EVENT_SUBSCRIBE:
			case EVENT_SUBSCRIBE_TIKECT:
				iWerchatEvent.subscribe(body);
				break;
			//当取消关注后	
			case EVENT_UNSUBSCRIBE:
				iWerchatEvent.unSubscribe(body);
				break;
			default:
				break;
		}
	}
	
}
