package org.jsoncloud.framework.allpay.wx.sessionserver.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import org.apache.log4j.Logger;
import org.jsoncloud.framework.allpay.wx.exception.ConnectNonOpenException;
import org.jsoncloud.framework.allpay.wx.sessionserver.IBaseSupportServer;
import org.jsoncloud.framework.allpay.wx.util.GetterFactory;
import org.jsoncloud.framework.allpay.wx.util.HttpRequestUtil;
import org.jsoncloud.framework.allpay.wx.util.JsonUtil;

/*******************************************************************************
 * 单例
 * @author sundhu
 *
 */
public class BaseSupportServerImpl implements IBaseSupportServer {

    // https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET
    private static Logger logger = Logger
            .getLogger(BaseSupportServerImpl.class);

    private BaseSupportServerImpl() {
    }

    private static BaseSupportServerImpl instance = null;

    public static BaseSupportServerImpl getInstance() {
        if (instance == null) instance = new BaseSupportServerImpl();
        return instance;
    }

    /**
     * access_token是公众号的全局唯一票据，公众号调用各接口时都需使用access_token。开发者需要进行妥善保存。access_token的存储至少要保留512个字符空间。access_token的有效期目前为2个小时，需定时刷新，重复获取将导致上次获取的access_token失效。<br>
     * 该方法将获取的access_token为一个全局静态缓存，由第三方线程(该线程必须先于容器启动)维护该值，第三方线程会根据access_token失效时间，定时刷新值。<br>
     * 所以当你调用该方法时，总是可以拿到最新的可用的access_token值。<br>
     */
    public String getAccessToken() {
        try {
            return GetterFactory.getter().getAccessToken();
        } catch (ConnectNonOpenException e) {
            logger.error(e);
        }
        return null;
    }

    private String ipurl = "https://api.weixin.qq.com/cgi-bin/getcallbackip?access_token=";
    private HttpRequestUtil requst = new HttpRequestUtil();

    public List<String> getWxServerIp(String accessToken) {
        try {
            String str = requst.httpResultHasHeader(ipurl + accessToken, null);
            JSONObject json = JSON.parseObject(str);
            JSONArray arr = json.getJSONArray("ip_list");
            if (arr == null || arr.size() <= 0) return null;
            List<String> iplist = new ArrayList<String>();
            for (int i = 0; i < arr.size(); i++) {
                iplist.add(arr.getString(i));
            }
            return iplist;
        } catch (Exception e) {
            logger.error("获取微信IP列表时异常", e);
            return null;
        }
    }

    public Map<String, Object> getGrantWxInfo(String accessToken, String openid) throws IOException, JSONException {
        String geturl = "https://api.weixin.qq.com/sns/userinfo?access_token=" + accessToken + "&openid=" + openid + "&lang=zh_CN";
        String resultstr = requst.httpResultHasHeader(geturl, null);
        //System.out.println("json----------"+json);
        return JsonUtil.getMapByJson(JSON.parseObject(resultstr));
    }

    public Map<String, Object> sendInfoToWxClient(String message, String accesstoken, String openid) throws IOException, JSONException {
        String posturl = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=" + accesstoken;
        String postData = "{\"touser\":\"" + openid + "\",\"msgtype\":\"text\",\"text\":{\"content\":\"" + message + "\"}}";
        String resultstr = requst.httpResultHasHeader(posturl, postData);
        return JsonUtil.getMapByJson(JSON.parseObject(resultstr));
    }

    public Map<String, Object> getWXUserInfoByOpenid(String accesstoken, String openid) throws IOException, JSONException {
        //System.out.println("accesstoken----------"+accesstoken);
        //System.out.println("openid----------"+openid);
        String geturl = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=" + accesstoken + "&openid=" + openid + "&lang=zh_CN";
        System.out.println(geturl);
        String resultstr = requst.httpResultHasHeader(geturl, null);
        //System.out.println("json----------"+json);
        return JsonUtil.getMapByJson(JSON.parseObject(resultstr));
    }


}
