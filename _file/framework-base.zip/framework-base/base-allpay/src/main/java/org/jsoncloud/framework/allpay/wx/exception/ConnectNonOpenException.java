package org.jsoncloud.framework.allpay.wx.exception;

public class ConnectNonOpenException extends Exception{
	public ConnectNonOpenException(String mes,Exception e){
		super(mes,e);
	}
}
