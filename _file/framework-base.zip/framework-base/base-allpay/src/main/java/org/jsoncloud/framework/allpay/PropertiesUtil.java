package org.jsoncloud.framework.allpay;

import org.jsoncloud.framework.util.StringUtil;

/**
 * Created by Administrator on 2017/3/25.
 */
public class PropertiesUtil extends org.jsoncloud.framework.util.PropertiesUtil {

    /**************
     *  阿里支付配置
     ****************/
    public static String getAlipayPrivateKey() {
        return getMust("alipay_private_Key");
    }

    public static String getAlipayPublicKey() {
        return getMust("alipay_public_Key");
    }

    public static String getAlipayCharset() {
        return StringUtil.toString(get("alipay_charset"), "UTF-8");
    }
    
    public static String getAlipaySignType() {
        return StringUtil.toString(get("alipay_sing_type"), "RSA2");
    }

    //新接口sdk需要用到
    public static String getAlipayAppId(){
        return getMust("alipay_app_id");
    }

    public static String getAlipayServerUrl(){
        return getMust("alipay_server_url");
    }

    /**************
     *  微信APP支付参数
     ****************/
    public static String getWechatAppId() {
        return getMust("wechat_app_id");
    }
    public static String getWechatAppSecret() {
        return getMust("wechat_app_secret");
    }
    public static String getWechatAppMchid() {
        return getMust("wechat_app_mchid");
    }
    public static String getWechatApiPaykey() {
        return getMust("wechat_app_apikey");
    }

    /**************
     *  其他参数
     ****************/
    public static boolean getPayDebug() {
        if ("true".equals(get("pay_debug"))) {
            return true;
        } else {
            return false;
        }
    }

}
