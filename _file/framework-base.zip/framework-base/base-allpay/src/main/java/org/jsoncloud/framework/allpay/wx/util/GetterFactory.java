package org.jsoncloud.framework.allpay.wx.util;

import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.Properties;

/**
 * 中控线程的数据获取器
 * @author Administrator
 *
 */
public class GetterFactory {
	private static String confpath="othercontrol_conf.properties";
	private static Logger logger= Logger.getLogger(GetterFactory.class);
	private static Getter getter;
	static{
		pro=getConfProperties();
		String ip=getIp();
		int port=getPort();
		getter=new Getter(ip,port);
	}
	
	public static Getter getter(){
		return getter;
	}
	
	private static Properties pro;
	
	/**
	 * 获得conf.properties的对象
	 * @param path 
	 * 
	 * @return
	 */
	private static Properties getConfProperties() {
		Properties pro = new Properties();
		try {
			pro.load(GetterFactory.class.getClassLoader().getResourceAsStream(confpath));
			return pro;
		} catch (IOException e) {
			//e.printStackTrace();
			logger.error("请在src下配置othercontrol.properties文件，该文件中描述数据库的链接字\nip\tport");
			return null;
		}
	}
	
	
	public static String getIp(){
		return pro.getProperty("wx_ip");
	}
	
	public static int getPort(){
		return Integer.parseInt(pro.getProperty("wx_port").toString());
	}
	
	
	public static void main(String[] args) throws Exception{
		System.out.println(GetterFactory.getter.getValue("mchid"));
	}
}
