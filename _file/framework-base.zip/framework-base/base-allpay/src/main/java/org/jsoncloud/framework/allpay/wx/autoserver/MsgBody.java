package org.jsoncloud.framework.allpay.wx.autoserver;

import java.util.Map;


/**
 * 微信服务器post过来的消息体
 * @author sundhu
 *
 */
public class MsgBody {
	/**
	 * 消息类型
	 */
	private MsgType msgType;
	private String toUserName;
	private String fromUserName;
	private long createTime;
	private Map<String,String> srcMap;
	
	public MsgType getMsgType() {
		return msgType;
	}
	public void setMsgType(MsgType msgType) {
		this.msgType = msgType;
	}
	public String getToUserName() {
		return toUserName;
	}
	public void setToUserName(String toUserName) {
		this.toUserName = toUserName;
	}
	public String getFromUserName() {
		return fromUserName;
	}
	public void setFromUserName(String fromUserName) {
		this.fromUserName = fromUserName;
	}
	public long getCreateTime() {
		return createTime;
	}
	public void setCreateTime(long createTime) {
		this.createTime = createTime;
	}
	public Map<String, String> getSrcMap() {
		return srcMap;
	}
	public void setSrcMap(Map<String, String> srcMap) {
		this.srcMap = srcMap;
	}
	@Override
	public String toString() {
		return "MsgBody [msgType=" + msgType + ", toUserName=" + toUserName
				+ ", fromUserName=" + fromUserName + ", createTime="
				+ createTime + ", srcMap=" + srcMap + "]";
	}
	
	
}
