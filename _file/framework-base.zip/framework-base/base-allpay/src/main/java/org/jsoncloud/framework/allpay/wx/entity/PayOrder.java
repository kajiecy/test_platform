package org.jsoncloud.framework.allpay.wx.entity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 支付清单
 * @author Administrator
 *
 */
public class PayOrder {
	
	
	
	/**
	 * 货币类型 
	 */
	private String feeType="CNY";
	
	/**
	 * 总金额 非空<=0
	 */
	private int totalFee;
	
	/**
	 * 交易类型
	 * 取值如下：JSAPI，NATIVE，APP
	 */
	private String tradeType="JSAPI";
	
	
	
	
	/**
	 * 客户端IP 非空
	 */
	private String spbillCreateIp;
	
	
	/**
	 * 交易时间
	 */
	private String startTime;
	
	/**
	 * 结束时间
	 */
	private String endTime;
	
	/**
	 * 用户id，trade_type=JSAPI，此参数必传，用户在商户appid下的唯一标识
	 */
	private String openId;
	
	/**
	 * 商品订单号
	 */
	private String outTradeNo;

	public String getFeeType() {
		return feeType;
	}

	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}

	public int getTotalFee() {
		return totalFee;
	}

	public void setTotalFee(int totalFee) {
		if(totalFee<=0){throw new IllegalArgumentException("金额不能小于0");}
		this.totalFee = totalFee;
	}

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		if(tradeType.equals("JSAPI")||tradeType.equals("NATIVE")||tradeType.equals("APP")){
			this.tradeType = tradeType;
		}else{
			throw new IllegalArgumentException("tradeType必须为JSAPI,NATIVE,APP");
		}
	}

	/**
	 * 商品订单号
	 * @return
	 */
	public String getOutTradeNo() {
		return outTradeNo;
	}

	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}

	public String getSpbillCreateIp() {
		return spbillCreateIp;
	}

	/**
     * 判断IP格式和范围
     */
    String rexp = "([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])(\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])){3}";
    Pattern pat = Pattern.compile(rexp);  
	public void setSpbillCreateIp(String spbillCreateIp) {
	     Matcher mat = pat.matcher(spbillCreateIp);  
	     boolean ipAddress = mat.find();
		if(!ipAddress)throw new IllegalArgumentException("请传入正确的IP");
		this.spbillCreateIp = spbillCreateIp;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		if(this.tradeType.equals("JSAPI")){
			if(openId==null)throw new IllegalArgumentException("当tradeType为JSAPI时，openId为必选项");
		}
		this.openId = openId;
	}

	public PayOrder(int totalFee, String tradeType, String spbillCreateIp,
			String openId, String outTradeNo) {
		super();
		if(totalFee<=0){throw new IllegalArgumentException("金额不能小于0");}
		this.totalFee = totalFee;
		
		if(tradeType.equals("JSAPI")||tradeType.equals("NATIVE")||tradeType.equals("APP")){
			this.tradeType = tradeType;
		}else{
			throw new IllegalArgumentException("tradeType必须为JSAPI,NATIVE,APP");
		}
		if(spbillCreateIp!=null){
            Matcher mat = pat.matcher(spbillCreateIp);
            boolean ipAddress = mat.find();
            if(!ipAddress)throw new IllegalArgumentException("请传入正确的IP");
            this.spbillCreateIp = spbillCreateIp;
        }

		if(this.tradeType.equals("JSAPI")){
			if(openId==null)throw new IllegalArgumentException("当tradeType为JSAPI时，openId为必选项");
		}
		this.openId = openId;
		
		this.outTradeNo = outTradeNo;
	}

}
