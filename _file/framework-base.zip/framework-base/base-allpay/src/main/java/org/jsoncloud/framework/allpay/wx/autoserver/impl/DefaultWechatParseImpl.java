package org.jsoncloud.framework.allpay.wx.autoserver.impl;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.Element;
import org.jsoncloud.framework.allpay.wx.autoserver.IWechatParse;
import org.jsoncloud.framework.allpay.wx.autoserver.MsgBody;
import org.jsoncloud.framework.allpay.wx.autoserver.MsgType;

public class DefaultWechatParseImpl implements IWechatParse {
		
	
	@Override
	public MsgBody parseWxXml(Document doc) {
		MsgBody body=new MsgBody();
		Element root = doc.getRootElement();
		body.setToUserName(root.elementTextTrim("ToUserName")) ;
		body.setFromUserName(root.elementTextTrim("FromUserName"));
		body.setCreateTime(Long.parseLong(root.elementTextTrim("CreateTime")));
		
		String type = root.elementTextTrim("MsgType");
		if(type.equals("event")){
			String event = root.elementTextTrim("Event");
			if(event.equals("subscribe")){
				Element ticketElement = root.element("Ticket");
				body.setMsgType(ticketElement==null? MsgType.EVENT_SUBSCRIBE:MsgType.EVENT_SUBSCRIBE_TIKECT);
			}else if(event.equals("unsubscribe")){
				body.setMsgType(MsgType.EVENT_UNSUBSCRIBE);
			}
		}
		@SuppressWarnings("unchecked")
		List<Element> es = root.elements();
		Map<String,String> map = new HashMap<String,String>();
		for (Element element : es) {
			map.put(element.getName(), element.getTextTrim());
		}
		body.setSrcMap(map);
		return body;
	}

	
}
