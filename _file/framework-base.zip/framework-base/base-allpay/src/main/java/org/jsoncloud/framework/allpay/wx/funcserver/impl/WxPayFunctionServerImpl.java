package org.jsoncloud.framework.allpay.wx.funcserver.impl;
import java.io.IOException;
import org.apache.log4j.Logger;
import org.jsoncloud.framework.allpay.wx.entity.WxPay;
import org.jsoncloud.framework.allpay.wx.funcserver.IWxPayFuncServer;
import org.jsoncloud.framework.allpay.wx.util.HttpRequestUtil;

/**
 * 支付服务 
 * @author Administrator
 *
 */
public class WxPayFunctionServerImpl implements IWxPayFuncServer {
	private static Logger logger=Logger.getLogger(WxPayFunctionServerImpl.class);
	private String unifyorderUrl="https://api.mch.weixin.qq.com/pay/unifiedorder";
	private HttpRequestUtil request=new HttpRequestUtil();
	public String wxUnifyPrePayOrder(WxPay pay, String apiCertPath) throws IOException{
		String order=pay.getResultForPay();
		logger.debug("发送统一下单htts请求：\n"+order);
		String result=null;
		if(apiCertPath==null){
			result = this.request.httpResultHasHeader(this.unifyorderUrl, order);
		}else{
			
		}
		logger.debug("获得统一下单回复：\n"+result);
		return result;
	}
	
}
