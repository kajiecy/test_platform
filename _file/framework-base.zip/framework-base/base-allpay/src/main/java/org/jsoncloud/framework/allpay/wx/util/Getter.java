package org.jsoncloud.framework.allpay.wx.util;

import org.jsoncloud.framework.allpay.wx.exception.ConnectNonOpenException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ResourceBundle;

public class Getter {
	private Socket s;
	private InputStream is;
	private OutputStream os;
	private String ip;
	private int port;

	public Getter(String ip, int port) {
		this.ip = ip;
		this.port = port;
	}

	private boolean status = false;

	public void close() {
		this.status = false;
		try {
			if (this.is != null)
				this.is.close();
		} catch (Exception e) {
		}
		try {
			if (this.os != null)
				this.os.close();
		} catch (Exception e) {
		}
		try {
			if (this.s != null)
				this.s.close();
		} catch (Exception e) {
		}
	}

	public boolean connect()  {
		this.close();
		try {
			this.open();
		} catch (IOException e) {
			this.close();
			this.status=false;
		}
		return this.status;
	}

	private void open() throws IOException {
		this.s = new Socket(ip, port);
		this.is = this.s.getInputStream();
		this.os = this.s.getOutputStream();
		this.s.setSoTimeout(5000);//设置超时时间为5秒
		this.status = true;
	}

	public boolean isClose() {
		return this.status;
	}

	public String getAccessToken() throws ConnectNonOpenException{
		return this.getRequest("accesstoken");
	}
	
	public String getJsApiTicket() throws ConnectNonOpenException{
		return this.getRequest("jsapiticket");
	}
	
	private static ResourceBundle resb1 = ResourceBundle.getBundle("wechat_conf");
	
	public String getValue(String key){
		return resb1.getString(key);
	}
	
	private String getRequest(String param) throws ConnectNonOpenException{
		if(param==null||param.trim().equals(""))throw new IllegalArgumentException("param不能为null");
		if(!this.isClose()){
			this.connect();
		}
		if(!this.status){this.close();throw new ConnectNonOpenException("获取"+param+"时 连接未打开，请查看IP及PORT是否正确，或者服务端出现异常",null);}
		try{
			byte[] senddata = param.getBytes("utf-8");
			this.os.write(senddata);
			byte[] bts = new byte[255];
			int size = this.is.read(bts);
			byte[] get = new byte[size];
			System.arraycopy(bts, 0, get, 0, size);
			String s =new String(get, "utf-8");
			if(s.equals("null"))return null;
			return s;
		}catch (Exception e) {
			this.close();
			throw new ConnectNonOpenException("获取"+param+"服务器已经关闭连接或读取超时，无法读取或写入",e);
		}
	}
	
	/*
	 * public static void main(String[] args) throws UnknownHostException,
	 * IOException { long start=System.currentTimeMillis(); Getter g=new
	 * Getter("127.0.0.1",4313); System.out.println(g.connect()); for(int i=0;i<10000;i++){
	 * g.getAccessToken(); }
	 * System.out.println(System.currentTimeMillis()-start); }
	 */
	
	

}
