package org.jsoncloud.framework.allpay.wx.templetmess;

/**
 * 微信模板消息接口
 * @author sundhu
 *
 */
public interface IWxTempletMessage {
	
	/**
	 * 发送模板消息的json字符串
	 * @return
	 */
	public String getMessageJson();
	
}
