package org.jsoncloud.framework.allpay.wx.autoserver;

import org.dom4j.Document;


public interface IWechatParse {
	
	/**
	 * 解析数据
	 * @return
	 */
	public MsgBody parseWxXml(Document docStream); 
	
}
