package org.jsoncloud.framework.allpay.wx;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.jsoncloud.framework.allpay.wx.util.EncryptUtil;
import org.jsoncloud.framework.allpay.wx.util.StringUtil;

import java.io.*;
import java.util.*;

/**
 * Created by Administrator on 2017/4/25.
 */
public class WechatCore {

    /**
     * 服务器响应成功
     */
    public static final String RESPONSE_SUCCESS = "SUCCESS";

    /**
     * 服务器响应失败
     */
    public static final String RESPONSE_FAIL = "FAIL";

    /**
     * 将请求参数重新包装
     *
     * @param paramMap
     * @return
     */
    public static Map<String, String> rewrapParamMap(
            Map<String, String[]> paramMap) {
        Map<String, String> result = new HashMap<String, String>();
        for (Map.Entry<String, String[]> one : paramMap.entrySet()) {
            String name = one.getKey();
            String value = _value(one.getValue());
            if (StringUtil.isEmpty(value)) {
                continue;
            }
            result.put(name, value);
        }
        return result;
    }

    private static String _value(String values[]) {
        if (values == null || values.length == 0)
            return null;
        return values[0];
    }

    /***
     * 将request参数封闭成 key=value的字符串集
     *
     * @param params
     * @return
     */
    private static List<String> createLinks(Map<String, String> params) {
        List<String> links = new ArrayList<String>();
        for (Map.Entry<String, String> one : params.entrySet()) {
            String name = one.getKey();
            String value = (one.getValue());
            if (StringUtil.isEmpty(value)) {
                continue;
            } else if ("sign".equals(name)) {
                continue;
            }
            links.add(name + "=" + value);
        }
        return links;
    }

    /**
     * 将links参数集排序
     *
     * @param links
     * @return
     */
    private static String sortLinksString(List<String> links) {
        if (links == null || links.isEmpty())
            return null;
        StringBuffer result = new StringBuffer();
        Collections.sort(links);
        for (String one : links) {
            result.append("&").append(one);
        }
        return result.substring(1);
    }

    /**
     * 生成签名参数
     *
     * @return
     */
    private static String sign(List<String> links, String apiKey) {
        if (links == null || links.isEmpty())
            return null;
        String sortedLinks = sortLinksString(links);
        String toSign = sortedLinks + "&key=" + apiKey;
        String sign = EncryptUtil.md5Encode(toSign);
        return sign.toUpperCase();
    }

    public static String sign(Map<String, String> params, String apiKey) {
        List<String> links = createLinks(params);
        return sign(links, apiKey);
    }

    /**
     * 根据参数生成xml请求报文
     *
     * @param param
     * @return
     */
    public static String createXmlFrom(Map<String, String> param) {
        if (param == null || param.isEmpty())
            return "";
        Document doc = DocumentHelper.createDocument();
        Element root = doc.addElement("xml");
        for (Map.Entry<String, String> one : param.entrySet()) {
            String name = one.getKey();
            String value = (one.getValue());
            root.addElement(name).setText(value == null ? "" : value);
        }
        return root.asXML();
    }

    /**
     * 从响应结果xml解析成map
     *
     * @param xml
     * @return
     */
    @SuppressWarnings("unchecked")
    public static Map<String, String> parseMapFrom(String xml) {
        if (StringUtil.isEmpty(xml))
            return null;
        Map<String, String> result = new HashMap<String, String>();
        SAXReader reader = new SAXReader();
        try {
            Document doc = reader.read(new ByteArrayInputStream(xml
                    .getBytes("UTF-8")));
            Element root = doc.getRootElement();
            for (Iterator<Element> it = root.elementIterator(); it.hasNext();) {
                Element e = it.next();
                result.put(e.getName(), e.getTextTrim());
            }
        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        }
        return result;
    }


    private static void _log(String fileName, String word) {
        FileWriter writer = null;
        try {
            writer = new FileWriter(fileName, true);
            writer.write(word + System.getProperty("line.separator"));
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
