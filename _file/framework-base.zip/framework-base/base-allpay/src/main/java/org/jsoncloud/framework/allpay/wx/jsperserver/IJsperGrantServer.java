package org.jsoncloud.framework.allpay.wx.jsperserver;

import java.io.IOException;
import java.util.Map;

import com.alibaba.fastjson.JSONException;


/**
 * 网页授权信息 接口
 * @author sundhu
 *
 */
public interface IJsperGrantServer {
	
	/**
	 * 官方介绍：jsapi_ticket是公众号用于调用微信JS接口的临时票据。
	 * 正常情况下，jsapi_ticket的有效期为7200秒，通过access_token来获取。
	 * 由于获取jsapi_ticket的api调用次数非常有限，频繁刷新jsapi_ticket会导致api调用受限，影响自身业务，开发者必须在自己的服务全局缓存jsapi_ticket 。<br>
	 * 推荐实现方式：由第三方中控（线程、进程）维护该值，该方法直接获取第三方的中控的缓存
	 * @return
	 */
	public String getJsApiTicket();
	
	
	/**
	 * 获得JS-SDK接口调用页面的wx-config所需要的参数
	 * @param jsApiTicket 页面调用js-sdk的临时票据
	 * @param appId
	 * @param url 该url为调用js-api的前端页面的完整URL，包含?后面的参数，但不包括#后面的值
	 * @return
	 * {<br>
	 * 	"noncestr":"noncestr",<br>
	 *  "signature":"signature",<br>
	 *  "timestamp":12234323,<br>
	 *  "appId":"appId"<br>
	 * }<br>
	 */
	public  Map<String,Object> getJsperWxConfig(String jsApiTicket, String appId, String url);
	
	/**
	 * 当调用微信支付JS接口时，传入packagestr(即 "prepay_id=*****")及appid,生成JS支付所需的参数
	 * 
	 * @param prepayid
	 * @return
	 */
	public Map<String,Object> getJsperWxPayParam(String appid, String paykey, String packagestr);
	
	/**
	 * 官方介绍：通过前台传过来的code(该code由微信服务器转发到网页授权页时获得),<br>
	 * 获取access_token(该acceess_token与全局access_token不同，为专门获取用户信息的凭证)，及用户openId
	 * @param appId
	 * @param secret
	 * @param code
	 * @return
	 * {
		   "access_token":"ACCESS_TOKEN",
		   "expires_in":7200,
		   "refresh_token":"REFRESH_TOKEN",
		   "openid":"OPENID",
		   "scope":"SCOPE",
		   "unionid": "o6_bmasdasdsad6_2sgVt7hMZOPfL"
	   }
	 */
	public Map<String,Object> getAccessTokenAndOpenIdByCode(String appId, String secret, String code) throws IOException,JSONException;
	
	/**
	 * 刷新网页授权页的accesstoken
	 * @param appId
	 * @param refreshToken
	 * @return
	 * @throws IOException
	 * @throws JSONException
	 */
	public Map<String,Object> getRefreshAccessTokenByOAuth(String appId, String refreshToken) throws IOException,JSONException;
}
