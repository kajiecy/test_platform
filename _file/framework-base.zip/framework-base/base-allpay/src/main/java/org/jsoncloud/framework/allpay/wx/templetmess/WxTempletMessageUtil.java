package org.jsoncloud.framework.allpay.wx.templetmess;

import java.io.IOException;

import org.jsoncloud.framework.allpay.wx.exception.ConnectNonOpenException;
import org.jsoncloud.framework.allpay.wx.util.HttpRequestUtil;

/**
 * 发送模板消息的工具类
 * @author sundhu
 *
 */
public final class WxTempletMessageUtil {
	
	public static String requestURL="https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=";
	public static HttpRequestUtil request=new HttpRequestUtil();
	public static String sendMessage(IWxTempletMessage message) throws ConnectNonOpenException, IOException{
		String str = message.getMessageJson();
		String accesstoken = "gFzjwFJy-5RDjFfCNjQNnpLBK6MzA5KALPsYKlWgwCpFpUJP5mBEK6XKnGJRyuPooyGgFJ5IU9_CmbaMS7AYsctossCoCVIDdATVNYgFqZ8";//GetterFactory.getter().getAccessToken();
		String  result = request.httpResultHasHeader(requestURL+accesstoken, str);
		return result;
	}
}
