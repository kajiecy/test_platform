package org.jsoncloud.framework.allpay.wx.untifycall;

import org.apache.log4j.Logger;
import org.jsoncloud.framework.allpay.wx.entity.WxPay;
import org.jsoncloud.framework.allpay.wx.funcserver.IWxPayFuncServer;
import org.jsoncloud.framework.allpay.wx.funcserver.impl.WxPayFunctionServerImpl;
import org.jsoncloud.framework.allpay.wx.jsperserver.IJsperGrantServer;
import org.jsoncloud.framework.allpay.wx.jsperserver.impl.JsperGrantServerImpl;
import org.jsoncloud.framework.allpay.wx.sessionserver.IBaseSupportServer;
import org.jsoncloud.framework.allpay.wx.sessionserver.impl.BaseSupportServerImpl;
import org.jsoncloud.framework.allpay.wx.util.GetterFactory;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * 微信统一调用服务类 
 * @author Jack
 *
 */
public class WechatUnifyService {
	private static Logger logger= Logger.getLogger(WechatUnifyService.class);
	private static IJsperGrantServer jsper= JsperGrantServerImpl.getInstance();
	private static IWxPayFuncServer wxpay=new WxPayFunctionServerImpl();
	private static IBaseSupportServer basesupport= BaseSupportServerImpl.getInstance();
	
	/**
	 *前端页面 在调用js-api时需要的参数
	 * @param href
	 * @return
	 * {<br>
	 * "noncestr":"noncestr",<br>
	 *  "signature":"signature",<br>
	 *  "timestamp":12234323,<br>
	 *  "appId":"appId"<br>
	 *  }<br>
	 */
	public static Map<String,Object> getWxConfig(String href) throws Exception{
		String currentPath=href;
		if(href.indexOf("#")>=0){
			href=href.substring(0,href.indexOf("#"));
		}
		try{
			String jsApiTicket =  jsper.getJsApiTicket();
			String appid = GetterFactory.getter().getValue("appid");
			return jsper.getJsperWxConfig(jsApiTicket, appid, currentPath);
		}catch (Exception e) {
			logger.error("获取前端页面JSAPI验证出现异常,返回 null",e);
			throw e;
		}
	}
	
	/**
	 * @param packagestr
	 * @return appId, timeStamp, nonceStr, package, signType,paySign
	 */
	public static Map<String,Object> getWxpayParam(String packagestr) throws Exception{
		try{
			String appid=GetterFactory.getter().getValue("appid");
			String paykey=GetterFactory.getter().getValue("paykey");
			return jsper.getJsperWxPayParam(appid, paykey,packagestr);
		}catch (Exception e){
			logger.error("获取前端页面JSAPI调用支付出现异常,返回 null",e);
			throw e;
		}
	}
	
	
	
	/**
	 * 根据openid返回对应的微信账户信息，例如 昵称等<br>
	 * 注意 ；如果用户没有关注该微信公众账号，则返回获取不到
	 * @param openId
	 * @return
	 * {<br>
    "subscribe": 1,<br>
    "openid": "o7Lp5t6n59DeX3U0C7Kric9qEx-Q",<br>
    "nickname": "方倍",<br>
    "sex": 1,<br>
    "language": "zh_CN",<br>
    "city": "深圳",<br>
    "province": "广东",<br>
    "country": "中国",<br>
    "headimgurl": "http://wx.qlogo.cn/mmopen/Kkv3HV30gbEZmoo1rTrP4UjRRqzsibUjT9JClPJy3gzo0NkEqzQ9yTSJzErnsRqoLIct5NdLJgcDMicTEBiaibzLn34JLwficVvl6/0",<br>
    "subscribe_time": 1389684286<br>
	}
	 */
	public static Map<String,Object> getWxInfoByOpenId(String openId){
		try{
			String accesstoken=GetterFactory.getter().getAccessToken();
			Map<String,Object> map = basesupport.getWXUserInfoByOpenid(accesstoken, openId);
			if(map.get("openid")==null)return null;
			return map;
		}catch (Exception e) {
			logger.error("获取关注该公众号的用户微信信息异常",e);
			//throw e ;
			return null;
		}
	}
	
	
	/**
	 * 根据微信传过来的code，获取用户openid
	 * @return
	 * { <br>
	 * "access_token":"ACCESS_TOKEN", <br>
	 * "expires_in":7200, <br>
	 * "refresh_token":"REFRESH_TOKEN", <br>
	 * "openid":"OPENID", <br>
	 * "scope":"SCOPE",<br>
	 *  "unionid": "o6_bmasdasdsad6_2sgVt7hMZOPfL" <br>
	 *  }<br>
	 */
	public static Map<String,Object> getJsperGrantInfoByCode(String code) throws Exception{
		try{
			String appid=GetterFactory.getter().getValue("appid");
			String secret=GetterFactory.getter().getValue("secret");
			//System.out.println(appid);
			//System.out.println(secret);
			Map<String,Object> map = jsper.getAccessTokenAndOpenIdByCode(appid, secret, code);
			System.out.print("grant-->:\n"+map);
			return map;
		}catch (Exception e) {
			logger.error("获取accesstoken及openid异常",e);
			throw e;
		}
	}
	
	/**
	 * 根据refreshAccessToken获取最新的网页授权accessToken
	 * @param refreshAccesstoken
	 * @return
	 * @throws Exception
	 */
	public static String getRefreshAccessToken(String refreshAccesstoken)throws Exception{
		try{
			String appid=GetterFactory.getter().getValue("appid");
			Map<String,Object> map = jsper.getRefreshAccessTokenByOAuth(appid, refreshAccesstoken);
			logger.info("根据refreshAccessToken获取最新的accessToken:\n"+map);
			if(map==null||map.get("access_token")==null){
				logger.warn("没有根据refreshAccessToken获取到最新的网页授权accesstoken:\n"+map);
				return  null;
			}
			return map.get("access_token").toString();
		}catch (Exception e) {
			logger.error("获取用户openid异常",e);
			throw e;
		}
	}
	
	/**
	 * 获取网页授权的微信信息
	 * @param accesstoken
	 * @param openid
	 * @return
	 */
	public static Map<String,Object> getGrantWxInfo(String accesstoken,String openid){
		try{
			Map<String,Object> map = basesupport.getGrantWxInfo(accesstoken, openid);
			System.out.println("grant info :\n"+map);
			if(map.get("openid")==null)return null;
			return map;
		}catch (Exception e) {
			logger.error("获取网页授权的用户微信信息异常",e);
			//throw e ;
			return null;
		}
	}
	
	/**
	 * 支付
	 * @param pay
	 * @return
	 */
	public static String pay(WxPay pay) throws Exception{
		try{
			return wxpay.wxUnifyPrePayOrder(pay, null);
		}catch (IOException e) {
			logger.error("支付产生IO异常,返回null,支付信息:\n"+pay.toString(),e);
			throw e;
		}
	}
	
	/**
	 * 验证是否来自微信的服务器
	 * @param ip
	 * @return
	 */
	public static boolean isWxServerIp(String ip){
		String accessToken=BaseSupportServerImpl.getInstance().getAccessToken();
		List<String> ips = BaseSupportServerImpl.getInstance().getWxServerIp(accessToken);
		for (String str : ips) {
			if(ip.equals(str))return true;
		}
		return false;
	}
	
	/**
	 * 获取全局accessTOken
	 * @return
	 */
	public static String getGloabAccessToken(){
		try{
			return GetterFactory.getter().getAccessToken();
		}catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 定向主动推送信息到微信客户端
	 * @param openid
	 * @param message
	 */
	public static void sendMessageToWxClient(String openid,String message){
		try{
			logger.info("向"+openid+"发送信息-->"+message);
			String accesstoken = GetterFactory.getter().getAccessToken(); 
			Map<String,Object> map = basesupport.sendInfoToWxClient(message, accesstoken, openid);
			logger.info("向"+openid+"发送信息，返回-->"+message);
		}catch (Exception e) {
			logger.error("向"+openid+"发送信息出现异常",e);
		}
	}
	
	/**
	 * 获得appid
	 * @return
	 */
	public static String getAppId(){
		try{
			return GetterFactory.getter().getValue("appid");
		}catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 获得商户号
	 * @return
	 */
	public static String getMchId(){
		try{
			return GetterFactory.getter().getValue("mchid");
		}catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 获得商户支付密钥
	 * @return
	 */
	public static String getPayKey(){
		try{
			return GetterFactory.getter().getValue("paykey");
		}catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 获得appid
	 * @return
	 */
	public static String getAppSercret(){
		try{
			return GetterFactory.getter().getValue("secret");
		}catch (Exception e) {
			return null;
		}
	}
	
	
	/**
	 * 判断是否来自微信浏览器 
	 * @return
	 */
	public static boolean isWechatBrowser(HttpServletRequest request){
		 return request.getHeader("user-agent").contains("MicroMessenger");
	}
	
	public static void main(String[] args) throws Exception {
//		String openid="oU1DrjuiGgnNTMwyooROkT--SyA0";//"oU1DrjhqB9cUkp0BEf_eNLg8j_nk";
//		long start=System.currentTimeMillis();
//		System.out.println(WechatUnifyService.getWxInfoByOpenId(openid));
//		System.out.println(System.currentTimeMillis()-start);

		System.out.println(getGloabAccessToken());
	}
	
	
	
	
	
}
