package org.jsoncloud.framework.allpay.wx.funcserver;

import java.io.IOException;
import java.util.Map;

import org.dom4j.DocumentException;
import org.jsoncloud.framework.allpay.wx.entity.WxPay;

/**
 * 微信支付服务 接口
 * @author Administrator
 *
 */
public interface IWxPayFuncServer {
	
	/**
	 * 微信统一下单支付接口（产生订单后先将信息提交到微信后台进行预下单，微信后台判断有效后方可进行下一步支付操作）<br>
	 * <br>
	 * 官方参数介绍：<br>
	 * 
	 * <table>
	  		<tr>
	  			<td>字段名</td>
	  			<td>变量名</td>
	  			<td>必填</td>
	  			<td>类型</td>
	  			<td>示例值</td>
	  			<td>描述</td>
	  		</tr>
	  		<tr>
	  			<td>公众账号ID</td>
	  			<td>appid</td>
	  			<td>是</td>
	  			<td>String(32)</td>
	  			<td>wx8888888888888888</td>
	  			<td>微信分配的公众账号ID</td>
	  		</tr>
	  		<tr>
	  			<td>商户号</td>
	  			<td>mch_id </td>
	  			<td>是</td>
	  			<td>String(32)</td>
	  			<td>1900000109</td>
	  			<td>微信支付分配的商户号</td>
	  		</tr>
	  		<tr>
	  			<td> 设备号</td>
	  			<td>device_info  </td>
	  			<td>否</td>
	  			<td>String(32)</td>
	  			<td>013467007045764</td>
	  			<td>终端设备号(门店号或收银设备ID)，注意：PC网页或公众号内支付请传"WEB"</td>
	  		</tr>
	  		<tr>
	  			<td> 随机字符串</td>
	  			<td>nonce_str   </td>
	  			<td>是</td>
	  			<td>String(32)</td>
	  			<td>5K8264ILTKCH16CQ2502SI8ZNMTM67VS</td>
	  			<td>随机字符串，不长于32位。推荐随机数生成算法</td>
	  		</tr>
	  		<tr>
	  			<td> 签名 </td>
	  			<td>sign   </td>
	  			<td>是</td>
	  			<td>String(32)</td>
	  			<td>C380BEC2BFD727A4B6845133519F3AD6</td>
	  			<td>签名，详见<a href="http://pay.weixin.qq.com/wiki/doc/api/index.php?chapter=4_3">签名生成算法</a></td>
	  		</tr>
	  		<tr>
	  			<td> 商品描述</td>
	  			<td>body </td>
	  			<td>是</td>
	  			<td>String(32)</td>
	  			<td>Ipad mini  16G  白色</td>
	  			<td>商品或支付单简要描述</td>
	  		</tr>
	  		<tr>
	  			<td> 商品详情</td>
	  			<td>detail</td>
	  			<td>否</td>
	  			<td>String(8192)</td>
	  			<td>Ipad mini  16G  白色</td>
	  			<td>商品名称明细列表</td>
	  		</tr>
	  		<tr>
	  			<td> 附加数据</td>
	  			<td>attach</td>
	  			<td>否</td>
	  			<td>String(127)</td>
	  			<td>说明</td>
	  			<td>附加数据，在查询API和支付通知中原样返回，该字段主要用于商户携带订单的自定义数据</td>
	  		</tr>
	  		<tr>
	  			<td>商户订单号</td>
	  			<td>out_trade_no</td>
	  			<td>是</td>
	  			<td>String(32)</td>
	  			<td>1217752501201407033233368018</td>
	  			<td>商户系统内部的订单号,32个字符内、可包含字母, 其他说明见商户订单号</td>
	  		</tr>
	  		<tr>
	  			<td>货币类型</td>
	  			<td>fee_type</td>
	  			<td>否</td>
	  			<td>String(16)</td>
	  			<td>CNY</td>
	  			<td>符合ISO 4217标准的三位字母代码，默认人民币：CNY，其他值列表详见货币类型</td>
	  		</tr>
	  		<tr>
	  			<td>总金额</td>
	  			<td>total_fee</td>
	  			<td>是</td>
	  			<td>Int</td>
	  			<td>888</td>
	  			<td>订单总金额，只能为整数，详见<a href="http://pay.weixin.qq.com/wiki/doc/api/index.php?chapter=4_2">支付金额</a></td>
	  		</tr>
	  		<tr>
	  			<td>终端IP</td>
	  			<td>spbill_create_ip</td>
	  			<td>是</td>
	  			<td>String(16)</td>
	  			<td>8.8.8.8</td>
	  			<td>APP和网页支付提交用户端ip，Native支付填调用微信支付API的机器IP。</td>
	  		</tr>
	  		<tr>
	  			<td>交易起始时间</td>
	  			<td>time_start</td>
	  			<td>否</td>
	  			<td>String(14)</td>
	  			<td>20091225091010</td>
	  			<td>订单生成时间，格式为yyyyMMddHHmmss，如2009年12月25日9点10分10秒表示为20091225091010。其他详见时间规则</td>
	  		</tr>
	  		<tr>
	  			<td>交易结束时间</td>
	  			<td>time_expire</td>
	  			<td>否</td>
	  			<td>String(14)</td>
	  			<td>20091225091010</td>
	  			<td>订单失效时间，格式为yyyyMMddHHmmss，如2009年12月27日9点10分10秒表示为20091227091010。其他详见时间规则</td>
	  		</tr>
	  		<tr>
	  			<td>商品标记</td>
	  			<td>goods_tag</td>
	  			<td>否</td>
	  			<td>String(32)</td>
	  			<td>WXG</td>
	  			<td>商品标记，代金券或立减优惠功能的参数，说明详见代金券或立减优惠</td>
	  		</tr>
	  		<tr>
	  			<td>通知地址</td>
	  			<td>notify_url</td>
	  			<td>是</td>
	  			<td>String(256)</td>
	  			<td>http://www.baidu.com/</td>
	  			<td>接收微信支付异步通知回调地址</td>
	  		</tr>
	  		<tr>
	  			<td>交易类型</td>
	  			<td>trade_type</td>
	  			<td>是</td>
	  			<td>String(16)</td>
	  			<td>JSAPI</td>
	  			<td>取值如下：JSAPI，NATIVE，APP，详细说明见参数规定</td>
	  		</tr>
	  		<tr>
	  			<td>商品ID</td>
	  			<td>product_id</td>
	  			<td>否</td>
	  			<td>String(32)</td>
	  			<td>12235413214070356458058</td>
	  			<td>trade_type=NATIVE，此参数必传。此id为二维码中包含的商品ID，商户自行定义。</td>
	  		</tr>
	  		<tr>
	  			<td>用户标识</td>
	  			<td>openid</td>
	  			<td>否</td>
	  			<td>String(128)</td>
	  			<td>oUpF8uMuAJO_M2pxb1Q9zNjWeS6o</td>
	  			<td>trade_type=JSAPI，此参数必传，用户在商户appid下的唯一标识。下单前需要调用【网页授权获取用户信息】接口获取到用户的Openid。</td>
	  		</tr>
	 * </table>
	 * @param appid32_y
	 * @param mch_id32_y
	 * @param device_info32_n
	 * @param nonce_str32_y
	 * @param signMD5_32_y
	 * @param body32_y
	 * @param detail_n
	 * @param attach127_n
	 * @param out_trade_no32_y
	 * @param fee_type16_n
	 * @param total_fee_y
	 * @param spbill_create_ip16_y
	 * @param time_start14_n
	 * @param time_expire14_n
	 * @param goods_tag32_n
	 * @param notify_url256_y
	 * @param trade_type16_y
	 * @param product_id32_n
	 * @param openid128_n
	 * @return
	 */
	public String wxUnifyPrePayOrder(WxPay pay, String certPath) throws IOException;
	
	
	/*
	 *String appid32_y,
			String mch_id32_y,
			String device_info32_n,
			String nonce_str32_y,
			String body32_y,
			String detail_n,
			String attach127_n,
			String out_trade_no32_y,
			String fee_type16_n,
			int total_fee_y,
			String spbill_create_ip16_y,
			String time_start14_n,
			String time_expire14_n,
			String goods_tag32_n,
			String notify_url256_y,
			String trade_type16_y,
			String product_id32_n,
			String openid128_n,
	 */
	
	
	
	
}
