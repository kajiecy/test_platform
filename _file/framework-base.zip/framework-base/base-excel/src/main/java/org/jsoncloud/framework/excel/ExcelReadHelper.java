package org.jsoncloud.framework.excel;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.read.biff.BiffException;
import org.apache.log4j.Logger;
import org.jsoncloud.framework.util.StringUtil;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * 读excel的操作
 */
public class ExcelReadHelper implements Enumeration<Map<String, Object>> {
    protected Logger logger = Logger.getLogger(getClass());

    private final File excel;
    private Workbook workbook;
    private Sheet[] sheets;// 要读取的子页
    private Map<Integer, String> header;// 列头信息

    private int currentSheetIndex = 0;
    private int currentRowIndex = 1;// 第一行是标题头

    public ExcelReadHelper(File excel) throws IOException {
        if (excel == null || !excel.exists() || !excel.isFile()) {
            throw new IOException("无效的excel文件：" + excel.getName());
        }
        this.excel = excel;
    }

    /**
     * 读取所有的sheet子页--可重复读取
     *
     * @param header 列头信息:<列索引（0开始）,列标记>
     * @throws IOException
     * @throws BiffException
     */
    synchronized public void loadAll(Map<Integer, String> header) throws IOException, BiffException {
        if (header == null) throw new NullPointerException("请指定读取表单的列头信息!");
        WorkbookSettings settings = new WorkbookSettings();
        this.workbook = Workbook.getWorkbook(this.excel, settings);
        int amount = workbook.getNumberOfSheets();
        List<Sheet> sheetList = new ArrayList<>(amount);
        for (int i = 0; i < amount; i++) {
            Sheet sheet = workbook.getSheet(i);
            if (sheet.getRows() <= 1) {
                logger.warn("## 读取sheet子页，当前页[index:" + i + "]没有任何信息，忽略读取！！:: 读取到的信息行数：" + sheet.getRows());
            } else {
                sheetList.add(sheet);
            }
        }
        this.sheets = sheetList.toArray(new Sheet[sheetList.size()]);
        this.header = header;
        currentSheetIndex = 0;
        currentRowIndex = 0;//第一行是标题头,起始索引放在数据之前,方便后面读取
        logger.info("## 加载Excel,共" + this.sheets.length + "页");
    }

    /**
     * 读取指定索引位置的sheet子页(从0开始)--可重复读取
     *
     * @param header       列头信息:<sheet子页的列索引（0开始）,生成结果的列标记（不要重复，否则会产生列覆盖）>
     * @param sheetIndexes 要读取的sheet子页索引
     * @return
     * @throws IOException
     * @throws BiffException
     */
    synchronized public void loadAt(Map<Integer, String> header, int... sheetIndexes) throws IOException, BiffException {
        if (header == null) throw new NullPointerException("请指定读取表单的列头信息!");
        if (sheetIndexes == null || sheetIndexes.length == 0) throw new NullPointerException("请指定读取表单的子页索引!");
        WorkbookSettings settings = new WorkbookSettings();
        this.workbook = Workbook.getWorkbook(this.excel, settings);
        this.header = header;
        List<Sheet> sheetList = new ArrayList<>(sheetIndexes.length);
        for (int i = 0; i < sheetIndexes.length; i++) {
            Sheet sheet = workbook.getSheet(sheetIndexes[i]);
            if (sheet.getRows() <= 1) {
                logger.warn("## 读取sheet子页，当前页没有任何信息，忽略读取！！:: 读取到的信息行数：" + sheet.getRows());
            } else {
                sheetList.add(sheet);
            }
        }
        this.sheets = sheetList.toArray(this.sheets);
        currentSheetIndex = 0;
        currentRowIndex = 0;//第一行是标题头,起始索引放在数据之前,方便后面读取
        logger.info("## 加载Excel,共" + this.sheets.length + "页");
    }

    @Override
    synchronized public boolean hasMoreElements() {
        if (this.sheets == null) throw new NullPointerException("请先使用load..()方法初始化表格!");
        logger.info("## ---读取Excel--- sheets.length:" + sheets.length + ",currentSheetIndex:" + currentSheetIndex + ",currentRowIndex:" + currentRowIndex + ",sheets[sheets.length - 1].getRows():" + sheets[sheets.length - 1].getRows());
        //读取到最后一行最后一条记录时就没有了~
        return currentSheetIndex < sheets.length - 1 || (currentSheetIndex == sheets.length - 1 && currentRowIndex < sheets[sheets.length - 1].getRows() - 1);
    }

    @Override
    synchronized public Map<String, Object> nextElement() {
        if (!hasMoreElements()) throw new IndexOutOfBoundsException("已经没有更多可以读取的数据！");
        currentRowIndex++;
        if (currentRowIndex >= sheets[currentSheetIndex].getRows()) {
            currentRowIndex = 1;
            currentSheetIndex++;
        }
        Map<String, Object> result = new HashMap<>();
        for (Map.Entry<Integer, String> colInfo : this.header.entrySet()) {
            Cell cell = sheets[currentSheetIndex].getCell(colInfo.getKey(), currentRowIndex);
            String content = cell.getContents();
            if (StringUtil.hasEmpty(content)) {
                result.put(colInfo.getValue(), content);
            }
        }
        return result;
    }


    synchronized public void close() {
        this.workbook.close();
    }
}
