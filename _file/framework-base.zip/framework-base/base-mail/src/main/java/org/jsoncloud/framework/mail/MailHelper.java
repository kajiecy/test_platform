package org.jsoncloud.framework.mail;

import com.sun.mail.util.MailSSLSocketFactory;

import javax.mail.*;
import javax.mail.Message.RecipientType;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.GeneralSecurityException;
import java.security.Security;
import java.util.Properties;

public class MailHelper {

    private String[] bcc;
    private String[] cc;
    private String[] to;
    private Properties props;
    private Session session;
    private String password;
    private String user;
    private String fromEmail;

    public MailHelper(String smtpHost, String fromEmail, String password, String[] to) {
        this(smtpHost, null, fromEmail, password, to, null, null);
    }

    public MailHelper(String smtpHost, Integer port, final String fromEmail, final String password, String[] to, String[] cc, String[] bcc) {
        if (to == null && cc == null && bcc == null)
            throw new NullPointerException();
        this.to = to;
        this.cc = cc;
        this.bcc = bcc;

        this.fromEmail = fromEmail;
        this.user = fromEmail.substring(0, fromEmail.indexOf("@"));
        this.password = password;

        this.props = new Properties();
        this.props.setProperty("mail.smtp.host", smtpHost); // mail.host
        if (port != null && port.intValue() > 0) {
            this.props.setProperty("mail.smtp.port", port.toString());
            this.props.setProperty("mail.smtp.socketFactory.port", port.toString());
        } else {
            this.props.setProperty("mail.smtp.port", "465");
            this.props.setProperty("mail.smtp.socketFactory.port", "465");
        }
        //设置SSL连接、邮件环境
        Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
        final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";
        this.props.setProperty("mail.smtp.socketFactory.class", SSL_FACTORY);
        this.props.setProperty("mail.smtp.socketFactory.fallback", "false");
        this.props.setProperty("mail.smtp.auth", "true");
        this.props.setProperty("mail.transport.protocol", "smtp");

        MailSSLSocketFactory sf = null;
        try {
            sf = new MailSSLSocketFactory();
        } catch (GeneralSecurityException e) {
            e.printStackTrace(System.err);
        }
        sf.setTrustAllHosts(true);
        props.put("mail.smtp.ssl.enable", "true");
        props.put("mail.smtp.ssl.socketFactory", sf);

        this.session = Session.getDefaultInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(fromEmail, password);
            }
        });
        this.session.setDebug(true);
    }

    public void send(Message message) throws MessagingException {
        Transport t = session.getTransport();
        t.connect(user, password);
        t.sendMessage(message, message.getAllRecipients());
    }

    /**
     * 创建一条简单邮件
     *
     * @param senderName 发件人显示的名称
     * @param title
     * @param text
     * @return
     * @throws AddressException
     * @throws MessagingException
     */
    public Message createSimpleMessage(String senderName, String title, String text) throws MessagingException {
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(fromEmail));
        String[][] target = {this.to, this.cc, this.bcc};
        RecipientType[] type = {RecipientType.TO, RecipientType.CC, RecipientType.BCC};
        for (int j = 0; j < target.length; j++) {
            if (target[j] != null) {
                for (int i = 0; i < target[j].length; i++) {
                    try {
                        InternetAddress addr = new InternetAddress(target[j][i]);
                        message.addRecipient(type[j], addr);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        try {
            message.setSubject(title);
            message.setContent(text, "text/html;charset=utf-8");
            message.setFrom(new InternetAddress(MimeUtility.encodeText(senderName) + " <" + fromEmail + ">"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return message;
    }

    public static void main(String[] args) throws MessagingException, UnsupportedEncodingException {

        String smtpHost = "smtp.mxhichina.com";
        String password = "Zhiding2017";
        String from = "contact@delightgo.com";
//        String smtpHost = "smtp.163.com";
//        String password = "jit2016";
//        String from = "jsoncloud@163.com";

        MailHelper helper = new MailHelper(smtpHost, null, from, password, new String[]{"546347964@qq.com"},
                new String[]{"zdc2643@163.com"}, new String[]{});
        String img = "helper://img3.imgtn.bdimg.com/it/u=2546610023,3120506294&fm=11&gp=0.jpg";
        img = URLEncoder.encode(img, "utf-8");
        helper.send(helper.createSimpleMessage("测试邮件", "测试邮件",
                "这是第一封测试邮件！"));

    }
}
