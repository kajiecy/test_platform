package org.jsoncloud.framework.mail;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import java.net.URLEncoder;

import static org.junit.Assert.*;

/**
 * Created by Administrator on 2017/3/16.
 */
public class MailHelperTest {
    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
//    @Ignore
    public void sendSimple() throws Exception {
        String smtpHost = "smtp.mxhichina.com";
        String password = "Zhiding2017";
        String from = "contact@delightgo.com";

        MailHelper helper = new MailHelper(smtpHost, null, from, password, new String[]{"546347964@qq.com"},
                new String[]{"zdc2643@163.com"}, new String[]{});
        String img = "helper://img3.imgtn.bdimg.com/it/u=2546610023,3120506294&fm=11&gp=0.jpg";
        img = URLEncoder.encode(img, "utf-8");
        helper.send(helper.createSimpleMessage("测试邮件", "测试邮件",
                "这是第一封测试邮件！"));
    }

}