package org.jsoncloud.framework.storage.qiniu;

import com.alibaba.fastjson.JSONObject;
import org.jsoncloud.framework.util.DateUtil;
import org.jsoncloud.framework.util.PropertiesUtil;
import com.qiniu.common.QiniuException;
import com.qiniu.http.Response;
import com.qiniu.storage.BucketManager;
import com.qiniu.storage.UploadManager;
import com.qiniu.util.Auth;
import com.qiniu.util.StringMap;
import org.apache.log4j.Logger;
import org.jsoncloud.framework.util.RandUtil;
import org.jsoncloud.framework.util.StringUtil;

import java.io.IOException;
import java.util.Date;

/**
 * 7牛图片上传工具
 *
 * @author Bames
 */
public class QiniuHelper {

    @Override
    public String toString() {
        return "QiniuHelper [keyName=" + keyName + ", bucketname=" + bucketname + ", auth=" + auth + ",  imageUrl="
                + imageUrl + "]";
    }

    private static Logger logger = Logger.getLogger(QiniuHelper.class);

    // 上传到七牛后保存的文件名
    private String keyName;
    private String bucketname;

    // 密钥配置
    private Auth auth;
    // 创建上传对象
    private UploadManager uploadManager;
    // 资源管理对象
    private BucketManager bucketManager;
    // 图片访问路径
    private String imageUrl;
    // 是否允许覆盖上传
    private boolean uploadOverride = false;

    /**
     * @param bucketname     空间名
     * @param keyName        上传到云的文件名
     * @param uploadOverride 上传时,是否允许重名图片覆盖,默认false
     */
    public QiniuHelper(String bucketname, String keyName, boolean uploadOverride) {
        this(bucketname, keyName);
        this.uploadOverride = uploadOverride;
    }

    /**
     * @param bucketname 空间名
     * @param keyName    上传到云的文件名
     */
    public QiniuHelper(String bucketname, String keyName) {
        this.bucketname = bucketname;
        this.keyName = keyName;
        String accessKey = PropertiesUtil.get("qiniu_access_key");
        String secretKey = PropertiesUtil.get("qiniu_secret_key");
        this.auth = Auth.create(accessKey, secretKey);
        this.uploadManager = new UploadManager();
        this.bucketManager = new BucketManager(this.auth);
    }

    // 上传token
    public String getUpToken() {
        if (!uploadOverride) {
            // <bucket>:<key>，表示只允许用户上传指定key的文件。在这种格式下文件默认允许“修改”，已存在同名资源则会被本次覆盖。
            // 如果希望只能上传指定key的文件，并且不允许修改，那么可以将下面的 insertOnly 属性值设为 1。
            // 第三个参数是token的过期时间
            return auth.uploadToken(bucketname, keyName, 3600, new StringMap().put("insertOnly", 1));// 图片命名不重复
        }
        //<bucket>:<key>，表示只允许用户上传指定key的文件。在这种格式下文件默认允许“修改”，已存在同名资源则会被本次覆盖。
        return auth.uploadToken(bucketname, keyName);
    }

    // 上传token
    /**
     * 参考：https://developer.qiniu.com/kodo/manual/1206/put-policy#put-policy-persistentPipeline 对象存储
     * 参考：https://developer.qiniu.com/dora  数据处理
     * eg：new StringMap().put("insertOnly", 1)
     * {
     * "scope":               "<Bucket                   string>",
     * "deadline":            "<UnixTimestamp            uint32>",
     * "insertOnly":          "<AllowFileUpdating        int>",
     * <p>
     * "endUser":             "<EndUserId                string>",
     * <p>
     * "returnUrl":           "<RedirectURL              string>",
     * "returnBody":          "<ResponseBodyForAppClient string>",
     * <p>
     * "callbackUrl":         "<RequestUrlForAppServer   string>",
     * "callbackHost":        "<RequestHostForAppServer  string>",
     * "callbackBody":        "<RequestBodyForAppServer  string>",
     * "callbackBodyType":    "<RequestBodyTypeForAppServer  string>",
     * "callbackFetchKey":    "<RequestKeyForApp         int>",
     * <p>
     * "persistentOps":       "<persistentOpsCmds        string>",
     * "persistentNotifyUrl": "<persistentNotifyUrl      string>",
     * "persistentPipeline":  "<persistentPipeline       string>",
     * "saveKey":             "<SaveKey                  string>",
     * "fsizeMin":            "<FileSizeMin              int64>",
     * "fsizeLimit":          "<FileSizeLimit            int64>",
     * <p>
     * "detectMime":          "<AutoDetectMimeType       int>",
     * <p>
     * "mimeLimit":           "<MimeLimit                string>",
     * "deleteAfterDays":     "<deleteAfterDays          int>"
     * }
     *
     * @param map
     * @return
     */
    public String getUpTokenVideo(StringMap map) {
        if (map != null) {
            return auth.uploadToken(
                    bucketname
                    , keyName,3600
                    , map);
        }
        return auth.uploadToken(
                bucketname
                , keyName);
    }

    /**
     * 上传成功后，返回访问图片的原图路径；上传失败时，返回空结果
     * @return
     */
    public String getUrl() {
        return imageUrl;
    }

    /**
     * 正方形最长边模式
     *
     * @param edge
     * @return
     */
    public String getUrlMaxSquare(int edge) {
        return getUrlMaxRectangle(edge, edge);
    }

    /**
     * 矩形最长边模式
     *
     * @param width
     * @param height
     * @return
     */
    public String getUrlMaxRectangle(int width, int height) {
        if (imageUrl == null)
            return null;
        return imageUrl + "?imageView2/0/w/" + width + "/h/" + height;
    }

    /**
     * 上传
     *
     * @param data 图片/资源数据
     * @return
     * @throws IOException 抛出QiniuException或IOException
     */
    public QiniuHelper upload(byte[] data) throws IOException {
        if (data == null || data.length == 0) {
            logger.error("## 图片上传失败,上传内容为空!");
            throw new NullPointerException("图片上传失败,上传内容为空");
        }
        // 调用put方法上传，这里指定的key和上传策略中的key要一致
        Response res = uploadManager.put(data, keyName, getUpToken());
        // 打印返回的信息
        String response = res.bodyString();
        logger.info("## 图片上传[bucket:" + bucketname + ",keyName:" + keyName + "]结果：" + response);
        JSONObject json = (JSONObject) JSONObject.parse(response);
        if (json.getString("error") != null || json.getString("code") != null) {
            throw new IOException("文件上传返回失败,反馈内容：" + response);
        }
        String key = json.getString("key");
        this.imageUrl = PropertiesUtil.get(this.bucketname);
        if (this.imageUrl.endsWith("/")) {
            this.imageUrl += key;
        } else {
            this.imageUrl += "/" + key;
        }
        return this;
    }

    /**
     * 删除资源
     */
    public void delete() throws QiniuException {
        this.bucketManager.delete(this.bucketname, this.keyName);
        logger.info("## 删除七牛资源：bucketname:" + this.bucketname + ",key:" + this.keyName);
    }


    /**
     * 批量删除
     *
     * @param bucket
     * @param keys
     * @throws QiniuException
     */
    public static void batchDelete(String bucket, String... keys) throws QiniuException {
        String accessKey = PropertiesUtil.get("qiniu_access_key");
        String secretKey = PropertiesUtil.get("qiniu_secret_key");
        Auth auth = Auth.create(accessKey, secretKey);
        BucketManager bucketManager = new BucketManager(auth);
        BucketManager.Batch batch = new BucketManager.Batch();
        batch.delete(bucket, keys);
        bucketManager.batch(batch);
    }

    /**
     * 获取最新的key
     *
     * @param preKey   前缀
     * @param filename 文件名称
     * @return
     */
    public static String buildKey(String preKey, String filename) {
        String key = "" + RandUtil.randomInt(3);
        key += DateUtil.date2String(new Date(), "yyMMddHHmmss");
        if (!StringUtil.hasEmpty(filename)) {
            int suffixIndex = filename.lastIndexOf(".");
            if (suffixIndex > 0) key += filename.substring(suffixIndex);
        }
        return preKey + key;
    }

}
