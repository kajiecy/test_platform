package org.jsoncloud.framework.storage;

/**

 */
public class PropertiesUtil extends org.jsoncloud.framework.util.PropertiesUtil {
    public String qiniuAccessKey() {
        return get("qiniu_access_key");
    }
    public String qiniuSecretKey() {
        return get("qiniu_secret_key");
    }
}
