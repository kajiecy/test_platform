package org.jsoncloud.framework.storage;

import org.jsoncloud.framework.storage.qiniu.QiniuHelper;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import java.io.File;
import java.io.FileInputStream;

/**
 * Created by Administrator on 2017/3/16.
 */
public class QiniuHelperTest {
    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    @Ignore
    public void upload() throws Exception {
        FileInputStream fis = new FileInputStream(new File("E:\\icon.jpg"));
        byte[] img = new byte[fis.available()];
        fis.read(img);
        QiniuHelper iu = new QiniuHelper("test", "icon1.png", true).upload(img);
        System.out.println(iu);
    }

    @Test
    @Ignore
    public void delete()throws Exception{
        new QiniuHelper("test", "icon1.png").delete();
    }
}
